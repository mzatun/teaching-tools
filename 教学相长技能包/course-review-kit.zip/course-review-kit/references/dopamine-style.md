# 多巴胺手绘风格规范（course-review-kit）

从 `arcpy-course-notes` 技能迁移的多巴胺手账风，用于本课件的 HTML 笔记。

## 配色变量（写在 `:root`）
```css
:root{
  --paper:#fdf4e3;   /* 米白纸张 */
  --paper2:#f7ecd6;  /* 卡片底 */
  --ink:#2b2b2b;     /* 黑色手绘线 */
  --orange:#FF6B35;  /* 关键字/重要概念 */
  --cyan:#00E5FF;    /* 函数名/工具名 */
  --purple:#FF00FF;  /* 字符串/特殊元素 */
  --yellow:#FFE135;  /* 数字/标注 */
  --mint:#98FF98;    /* 注释/辅助 */
  --coral:#FF6F61;   /* 关键路径/强调 */
  --sky:#87CEEB;     /* 背景装饰/UI */
}
```

## 字体（Google Fonts，需联网）
```html
<link href="https://fonts.googleapis.com/css2?family=Ma+Shan+Zheng&family=ZCOOL+KuaiLe&family=Noto+Sans+SC:wght@400;700&family=Patrick+Hand&display=swap" rel="stylesheet">
```
- 大标题 / 章节标题：`'Ma Shan Zheng', cursive`（毛笔感）
- 小标题 / 标注胶囊：`'ZCOOL KuaiLe', cursive`
- 正文：`'Noto Sans SC', sans-serif`（**概念讲解用清晰字体，别全用手写体影响阅读**）
- 英文手写：`'Patrick Hand', cursive`

## 手绘卡片
```css
.card{
  background:var(--paper);
  border:3px solid var(--ink);
  border-radius:255px 15px 225px 15px/15px 225px 15px 255px; /* 不规则手绘边 */
  box-shadow:5px 5px 0 rgba(43,43,43,.15);
  padding:26px 30px;
}
```

## 纸张纹理（背景 SVG 噪声 data URI）
```css
body{
  background-color:var(--paper);
  background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='120' height='120'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2'/%3E%3C/filter%3E%3Crect width='120' height='120' filter='url(%23n)' opacity='0.04'/%3E%3C/svg%3E");
}
```

## 组件类（直接复用）
- `.plain` 大白话气泡：白底粗框，左上角 `💡 大白话` 角标，用大白话翻译概念。
- `.formula` 公式框：虚线橙边，放 MathJax 公式。
- `.animbox` 动画演示框：白底粗框，内含 `.cap` 胶囊标题（如 `🎬 动画演示：…`），再放 `<svg>`。
- `.ex` 例题框：紫边，左上角 `📝 例题` 角标。
- `.note` / `.warn` 提示条：左色条 + 浅底色。
- `.summary` 本章小结：纸色底大框，含有序列表与口诀。
- 装饰：`🌟☁️💡❤️` 等 emoji 散布封面/章节。

## 封面与目录
- 封面：课程名（毛笔大字 + 同色 text-shadow 偏移）、副标题、标签胶囊、散布装饰 emoji。
- 目录 `.toc`：有序列表 + 锚点 `<a href="#s21">`，章节容器用 `id` 对应。
