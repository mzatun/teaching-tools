# 实战踩坑 Checklist（course-review-kit，写 HTML 后必查）

本清单来自真实踩坑。写完 HTML **必须跑 `scripts/svg_validator.py`**，按报错对照此处修复。

## 1. SVG 颜色兼容性（最高频）
- ❌ 坑：SVG 内写 `fill="var(--orange)"` 属性形式，部分浏览器不解析 → 配色全黑。
- ✅ 修：统一 `style="fill:var(--orange)"`。
- 修复命令（Python）：
  ```python
  import re
  s=open(p,encoding='utf-8').read()
  # 修"属性值引号丢失导致 style 直接拼接"：X="value  style="Y" -> X="value" style="Y"
  s=re.sub(r'(\w+)="([^"]*?)\s+style="', r'\1="\2" style="', s)
  # 简单场景：presentation attribute 形式转 style 属性
  s=re.sub(r'(fill|stroke|stop-color)="var\((--[\w-]+)\)"', r'style="\1:var(\2)"', s)
  open(p,'w',encoding='utf-8').write(s)
  ```
  注意：复杂情况（自闭合标签含 var，见坑2）需先修自闭合再转 style。

## 2. 自闭合标签被正则吸进属性（批量替换时）
- ❌ 坑：用 `<(\w+)([^>]*)>` 类正则处理含 `/>` 的自闭合标签时，`/` 被吸进 attrs，变成 `<circle ... / style="...">` 畸形（内部 ` / ` 错位，结尾不是 `/>`）。
- ✅ 修：把所有错位还原为正确的自闭合：
  ```python
  s=re.sub(r'(\S)"/(\s*style="[^"]*")(\s*)>', r'\1 \2\3/>', s)
  ```
  或最稳：写完直接跑 validator，按报错定位。

## 3. 重复 class 属性
- ❌ 坑：同一标签写两个 `class="..."`（如 `class="x" ... class="label"`），浏览器只认第一个，手写体样式丢失。
- ✅ 修：合并为 `class="x label"`。全文件排查：
  ```python
  dups=[l for l in s.splitlines() if re.search(r'class="[^"]*"[^>]*class="', l)]
  ```

## 4. SVG 逐块 XML 校验（交付前必跑）
```python
import re, xml.etree.ElementTree as ET
svgs=re.findall(r'<svg.*?</svg>', s, re.S)
for i,b in enumerate(svgs):
    ET.fromstring(b.replace('<svg','<svg xmlns="http://www.w3.org/2000/svg"',1))
```
报 `invalid token` / `duplicate attribute` 即结构坏，按坑1–3 修。

## 5. MathJax 配对
全文件 `$` 总数必须**偶数**（行内 `$x$` 与 `$$...$$` 都成对）。奇数说明公式被截断。

## 6. 整体标签配对
统计 `<div>`/`<svg>`/`<text>`/… 开闭数相等。差 1 常因某 `</div>` 被误改成 `</div4>` 之类（正则跨行破坏），需重建该行（参考 validator 输出定位）。

## 7. 公式截断连锁
批量正则若误伤正文（如把 `</div>` 与下一行 `<h4>` 拼接成 `</div4>③...`），会同时破坏 div/h4 配对。修复后重跑 validator 直到全绿。

## 一键自检
```bash
python3 scripts/svg_validator.py /sandbox/workspace/outputs/XXX_手绘笔记.html
```
退出码非 0 = 有问题，按上面清单修。
