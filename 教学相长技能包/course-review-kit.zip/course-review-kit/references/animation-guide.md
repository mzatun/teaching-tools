# SVG 动画演示规范（course-review-kit）

## 为什么用 SVG + CSS 而非位图
本技能**不依赖图像生成工具**。SVG 矢量 + CSS `@keyframes` 在所有现代浏览器直接跑：可无限缩放、体积小、易改色，且能"动"——比静态插画更贴合"动画演示"诉求。

## 🔴 最高优先级约束
**SVG 内颜色必须用 `style` 属性写 CSS 变量**：
```html
✅ <circle style="fill:var(--orange)" .../>
❌ <circle fill="var(--orange)" .../>   <!-- 老 Safari/内置 WebView 不解析，配色全黑 -->
```
批量转换与修复见 `pitfalls.md`。

## 动画循环模式
用 `animation: kf-name Ds linear infinite;` 自动循环。
**复位式 keyframes** 实现"循环演示"：在 keyframes 末尾把元素移回初始状态（如透明度归零再出现），避免 `infinite` 跳变突兀。

```css
@keyframes kf-slide{
  0%{transform:translateX(0);opacity:1}
  82%{transform:translateX(270px);opacity:1}
  92%{transform:translateX(270px);opacity:0}
  93%{transform:translateX(0);opacity:0}
  100%{transform:translateX(0);opacity:1}
}
.ball{animation:kf-slide 4.5s linear infinite;}
```

## transform 原点
SVG 元素做 `rotate`/`scale` 需设：
```css
.pend{transform-box:fill-box; transform-origin:top center;}
```
否则会绕 SVG 坐标原点旋转。

## 常见概念动画模式（直接套用）
| 概念 | 动画手法 |
|------|----------|
| 匀速 / 惯性 | 小球 `translateX` 循环移动 |
| F=ma | 两球不同加速度（`ease-in`），力大 / 质量小 → 位移大 |
| 第三定律 | 双向等大反向箭头 `opacity` 脉动 |
| 万有引力 | 两质点 + 双向箭头脉动 + `scale` 呼吸 |
| 胡克定律 | 弹簧路径 `translateX` 振荡 + 弹力箭头反向脉动 |
| 静 vs 动摩擦 | 上格静止平衡、下格移动，箭头方向对比 |
| 非惯性系 | 框架 `translateX` 加速 + 内部小球反向偏 + 惯性力箭头 |
| 剪断细线 | 线 `opacity` 消失 + 上球 `translateY` 下坠、下球不动（a₁=2g, a₂=0） |
| 终端速度 | 小球下落（`ease-out` 模拟收敛）+ 旁 v-t 指数曲线 + 渐近线虚线 |
| 机械能守恒 | 摆球 `rotate` 摆动 + 两条能量条(Eₖ/Eₚ)此消彼长 + 总能量条恒定 |
| 动量守恒 | 两球相向移动碰撞后弹开，总动量标注脉动 |
| 碰撞 | 上排弹性（速度交换）/ 下排完全非弹性（粘一起同速） |

## v-t 曲线动点（CSS Motion Path）
```css
.dot{offset-path:path('M180,150 C210,148 235,120 255,95 C270,78 280,68 340,61');
     offset-rotate:0deg; animation:kf-dot 3s linear infinite;}
@keyframes kf-dot{0%{offset-distance:0%}100%{offset-distance:100%}}
```
现代 Chrome / Edge / Firefox 支持。不支持时小球静止在原点，不影响其余演示。

## 全局暂停/播放（可选 JS）
右下角按钮 toggle `body.paused`，配合：
```css
body.paused *{animation-play-state:paused !important;}
```

## 箭头 marker 模板
```html
<defs><marker id="ar" markerWidth="10" markerHeight="10" refX="6" refY="3" orient="auto">
  <path d="M0,0 L6,3 L0,6 Z" style="fill:var(--coral)"/></marker></defs>
<line x1=".." y1=".." x2=".." y2=".." style="stroke:var(--coral)" marker-end="url(#ar)"/>
```
