#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
course-review-kit · HTML 笔记交付前自检

检查项：
  1. 每个 <svg> 块是否为合法 XML（补 xmlns 后用 xml.etree 解析）
  2. 主要 HTML 标签开闭是否配对
  3. MathJax 公式 $ / $$ 是否成对
  4. CSS @keyframes 是否全部被 animation 引用（无悬空、无缺失）
  5. 残留属性式 var()（应已转 style 属性）
  6. 空 style / CSS 双分号 / 重复 class 属性

用法：
  python3 svg_validator.py <html路径>
退出码：0=全绿，1=发现问题，2=参数/读取错误
"""
import re
import sys
import xml.etree.ElementTree as ET

TAGS = ['div', 'svg', 'text', 'defs', 'marker', 'h2', 'h3', 'h4',
        'ol', 'li', 'g', 'style', 'script', 'body', 'html']


def validate(path):
    try:
        s = open(path, encoding='utf-8').read()
    except Exception as e:
        print('读取失败:', e)
        return 2

    errs = []

    # 1. SVG 逐块 XML 合法性
    svgs = re.findall(r'<svg.*?</svg>', s, re.S)
    bad = 0
    for i, b in enumerate(svgs):
        blk = b.replace('<svg', '<svg xmlns="http://www.w3.org/2000/svg"', 1)
        try:
            ET.fromstring(blk)
        except Exception as e:
            bad += 1
            errs.append('SVG#%d 非法 XML: %s' % (i, e))
    if bad:
        errs.append('共有 %d / %d 个 SVG 非法' % (bad, len(svgs)))

    # 2. 标签配对
    for t in TAGS:
        o = len(re.findall(r'<%s[\s>]' % t, s))
        c = len(re.findall(r'</%s>' % t, s))
        if o != c:
            errs.append('标签 <%s> 不配对 %d/%d' % (t, o, c))

    # 3. MathJax 配对
    if s.count('$') % 2 != 0:
        errs.append('$ 总数奇数（公式未配对）')
    if s.count('$$') % 2 != 0:
        errs.append('$$ 奇数（独立公式未配对）')

    # 4. 动画 keyframes 定义 vs 使用
    kf = set(re.findall(r'@keyframes\s+([\w-]+)', s))
    used = set(re.findall(r'animation:\s*([\w-]+)\s', s))
    missing = used - kf
    if missing:
        errs.append('animation 使用了未定义的 keyframes: %s' % sorted(missing))

    # 5. 残留属性式 var()
    if s.count('fill="var(') or s.count('stroke="var(') or s.count('stop-color="var('):
        errs.append('残留 fill/stroke/stop-color="var( 属性形式（应转 style 属性）')

    # 6. 空 style / 双分号 / 重复 class
    if 'style=""' in s:
        errs.append('存在空 style=""')
    if ';;' in s:
        errs.append('CSS 双分号 ;;（空声明）')
    dups = sum(1 for l in s.splitlines()
               if re.search(r'class="[^"]*"[^>]*class="', l))
    if dups:
        errs.append('重复 class 属性行数: %d' % dups)

    # 报告
    print('SVG 块数      : %d (非法 %d)' % (len(svgs), bad))
    print('$ 总数        : %d (偶数: %s)' % (s.count('$'), s.count('$') % 2 == 0))
    print('$$ 数         : %d (偶数: %s)' % (s.count('$$'), s.count('$$') % 2 == 0))
    print('keyframes 定义: %d，使用未定义: %s'
          % (len(kf), sorted(missing) or '无'))
    print('文件字节      : %d' % len(s.encode('utf-8')))

    if errs:
        print('\n❌ 发现问题:')
        for e in errs:
            print('  -', e)
        print('\n请对照 references/pitfalls.md 修复后重跑。')
        return 1
    print('\n✅ 全部自检通过，可交付。')
    return 0


if __name__ == '__main__':
    if len(sys.argv) < 2:
        print('用法: python3 svg_validator.py <html路径>')
        sys.exit(2)
    sys.exit(validate(sys.argv[1]))
