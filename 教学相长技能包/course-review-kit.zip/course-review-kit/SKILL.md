---
name: course-review-kit
description: 课程专题复习资料制作（多巴胺手绘风 HTML 笔记 + 动画演示 + 配套练习题）。当用户说"做XX课程的复习笔记/动画笔记""把课件转成手绘笔记""生成某章复习资料/课后练习/刷题题"，或上传/指定了课程 PPT/PDF/Word 课件希望转化为可视化复习材料时触发。不适用于纯翻译、论文写作、非教学类文档整理、或单篇长文润色。
---

# 课程专题复习资料制作（Course Review Kit）

## 概述
把一门课的课件（PPT / PDF / Word）转化为两套可交付的复习资料：
1. **多巴胺手绘风 HTML 笔记**——纸张纹理 + 手写体 + 七色多巴胺配色，每个核心概念配一个**自循环 SVG/CSS 动画演示**，公式用 MathJax 渲染；
2. **配套练习题 MD**——5 道期末刷题题，含考点、分步解答、易错提醒、答案速查表。

视觉风格从 `arcpy-course-notes` 技能的多巴胺手绘方法论迁移而来，但把"静态配图"替换为"SVG 动画"——**不依赖任何图像生成工具**，浏览器直接跑。

## 何时读取参考文件
- 写 HTML 笔记前 → `references/dopamine-style.md`（配色变量、手绘 CSS、字体、纸张纹理）
- 设计动画前 → `references/animation-guide.md`（keyframes 模板、常见概念动画模式、兼容性坑）
- 生成练习前 → `references/exercise-template.md`（5 题 MD 结构）
- 写完 HTML 跑 `scripts/svg_validator.py` 自检 → 遇警告对照 `references/pitfalls.md`

## 你的工作方式（流程型，四步）

### Phase 1：获取与解析课件内容
- **输入来源**：知识库 `media_id`（用 `fetch type=media_id`）、上传文件、或用户贴文本。
- 若来源是知识库且用户只给课程名/章节名，先用 `search(source="kb", kb_id=...)` 定位文件，再 `fetch` 提取全文。
- **提取要求**：逐页列出标题、章节层级、正文要点、公式（含符号含义）、定义、定理、典型例题与解答。**保留原章节结构编号**，不遗漏任何概念与公式。
- **确认门**：若章节号与主题词冲突（如用户说"第1章 质点动力学"但库里是"第2章 质点动力学"），用 `ask_user` 确认，避免做错整章。

### Phase 2：生成多巴胺手绘 HTML 笔记 + 动画
- **一个 HTML 文件**，结构：封面 → 目录导航（锚点跳转）→ 各章节（💡大白话气泡 + 公式 + 🎬动画演示框）→ 本章小结。
- **视觉**：读 `references/dopamine-style.md` 取配色与 CSS。
- **动画**：读 `references/animation-guide.md`。每个核心概念至少 1 个 SVG 动画，用 CSS `@keyframes` + `infinite` 自动循环（纯 CSS 即可演示；可加一个全局"暂停/播放"按钮用少量 JS）。
- **🔴 最高优先级约束（血泪经验）**：SVG 内颜色一律用 `style="fill:var(--x)"` / `style="stroke:var(--x)"`，**绝不用** `fill="var(--x)"` 属性形式（老浏览器/内置 WebView 不解析，配色会全黑）。详见 `references/pitfalls.md`。
- 公式用 MathJax CDN：`$$...$$` 独立公式、`$...$` 行内。
- **输出路径**：`/sandbox/workspace/outputs/{章节名}_手绘笔记.html`。

### Phase 3：生成练习题 MD（每次必选）
- 读 `references/exercise-template.md`，出 **5 道**题，覆盖本章全部核心考点，且**区别于课件原例题**。
- 每题结构：题干 → 考点与思路 → 分步解答（**数值手算复核**）→ 易错提醒。
- 末尾附答案速查表 + 备考口诀。
- **输出路径**：`/sandbox/workspace/outputs/{章节名}_课后练习5题.md`。

### Phase 4：自检与交付
- **HTML 自检**：运行 `python3 scripts/svg_validator.py <html路径>`。必须全绿：SVG 全部合法 XML、所有 HTML 标签配对、MathJax `$` 偶数、动画 keyframes 全部被引用、无残留属性式 `var()`、无空 style。
- 若自检报错，对照 `references/pitfalls.md` 修复（多为 SVG 自闭合/引号/双 class 问题），重跑直到全绿。
- **交付**：用 `provide_file` 给 HTML 与 MD 的下载链接；回复中列出章节覆盖、动画清单、练习题考点映射。
- 其余步骤自主推进，自检全绿即可交付，无需每步打扰用户。

## 示例

### 示例 1：知识库课件转化
用户：`@大学物理教学库 用 arcpy-course-notes 风格，把 第2章 质点动力学.pptx 转成带动画的 HTML 笔记`
→ Phase1 `search` 定位 media_id → `fetch` 全文 → Phase2 写 HTML（12 个动画：惯性、F=ma、第三定律、引力、胡克、摩擦、非惯性系、剪断细线、终端速度、机械能守恒、动量守恒、碰撞）→ Phase3 出 5 题练习 → Phase4 `svg_validator` 全绿 → 交付下载链接。

### 示例 2：上传文件转化
用户上传 `高数第三章.pdf`："做成手绘复习笔记 + 刷题题"
→ Phase1 `fetch` pdf → Phase2/3 生成 HTML 与 MD → Phase4 自检交付。

## 资源目录

### scripts/
- `svg_validator.py`：HTML 交付前自检（SVG XML 合法性、标签配对、MathJax `$` 配对、动画类定义、残留 `var()` 检测），exit code 非 0 表示有问题。

### references/
- `dopamine-style.md`：配色变量、手绘 CSS、字体、纸张纹理。
- `animation-guide.md`：SVG 动画 keyframes 模板、常见概念动画模式、兼容性坑。
- `exercise-template.md`：5 题练习 MD 结构模板。
- `pitfalls.md`：实战踩坑 checklist（SVG 颜色、自闭合标签、双 class、XML 校验、公式配对）。
