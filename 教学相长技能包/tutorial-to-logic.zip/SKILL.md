---
name: tutorial-to-logic
description: 将软件操作教程转化为"数据对象→业务逻辑"的结构化HTML讲解页面，支持联网扩展知识体系和引用教程配图；当用户需要深入理解软件操作背后的数据结构和业务逻辑，而非机械记忆操作步骤时使用
---

# 软件操作数据对象与业务逻辑讲解生成器

## 任务目标
- 本 Skill 用于：将软件操作教程转化为"数据对象→业务逻辑"的结构化HTML讲解页面，支持深度知识扩展和教程配图引用
- 能力包含：提取教程中的数据对象、联网扩展知识体系、分析对象关系、推导业务逻辑、引用教程配图、生成可视化HTML页面
- 触发条件：用户需要深入理解软件操作背后的原理，而非表面步骤

## 前置准备
- 依赖说明：无外部依赖
- 非标准文件/文件夹准备：无

## 操作步骤
- 标准流程：
  1. **教程解析与对象提取**
     - 阅读用户提供的教程内容（文档链接或文本）
     - 识别教程中涉及的所有数据对象（如工程、布局、地图框、图层、要素等）
     - 对于每个对象，记录其在教程中的作用和引用位置

  2. **提取教程原文内容** ⭐
     - 从教程中提取与每个数据对象相关的原文内容
     - 包括：对象说明、操作步骤、注意事项等
     - 保留原文的关键表述和示例
     - 使用 [object-analysis-template.md](references/object-analysis-template.md) 中的"教程原文引用"字段记录

  3. **深度知识检索与扩展** ⭐
     - 参考 [analysis-methodology.md](references/analysis-methodology.md) 中的"知识体系扩展方法"
     - 对每个核心数据对象使用网络搜索获取权威定义：
       - 搜索官方文档（如 ArcGIS Pro 官方文档、Adobe 官方帮助）
       - 查找技术博客、社区最佳实践
       - 收集对象的完整特性、限制条件、使用场景
     - 构建完整的知识体系，确保原理讲解的深度和准确性
     - 将搜索结果整合到对象定义中，补充教程未覆盖的知识点

  3. **数据对象深度分析**
     - 参考 [analysis-methodology.md](references/analysis-methodology.md) 中的方法
     - 对每个核心数据对象进行定义：
       - 概念定义：对象是什么（基于官方文档和扩展搜索）
       - 本质作用：对象存在的价值
       - 包含内容：对象内部的子元素
       - 扩展知识：从搜索中获得的深度理解
     - 使用 [object-analysis-template.md](references/object-analysis-template.md) 作为分析框架

  3. **对象关系建模**
     - 分析对象之间的层次关系、组合关系、引用关系
     - 识别核心对象（容器/管理对象）和从属对象
     - 生成多种 Mermaid 结构图展示组织关系：
       - **类图（classDiagram）**：展示对象的属性、方法和类关系
       - **实体关系图（ERD）**：展示对象之间的数据关联
     - 参考 [mermaid-diagram-template.md](assets/mermaid-diagram-template.md) 获取详细示例

  4. **业务逻辑推导**
     - 基于对象关系和教程步骤，推导业务本质
     - 回答问题：这个操作在数据层面实际在做什么？
     - 例如：ArcGIS Pro 制作地图的本质 = 布局排版 + 地图框映射 + 图层叠加
     - 将业务逻辑分解为：准备阶段 → 数据组织 → 视图呈现 → 输出

  5. **操作流程图生成** ⭐
     - 基于教程的操作步骤，生成 Mermaid 流程图
     - 展示操作步骤的执行顺序和数据流转
     - 标注关键决策节点和数据转换点
     - 使用流程图（graph TD/LR）或状态图（stateDiagram）
     - 参考 [mermaid-diagram-template.md](assets/mermaid-diagram-template.md) 获取流程图示例

  6. **HTML页面生成**
     - 使用 [page-template.html](assets/page-template.html) 作为模板
     - 按以下结构组织内容：
       - 标题区域：软件名称 + 功能主题 + **教程链接按钮** ⭐
       - 原理板块：数据对象详解 + 教程原文引用 + **对象关系图（类图/ER图）** ⭐
       - 逻辑板块：业务本质 + 操作逻辑推导 + **操作流程图** ⭐
       - 过程板块：操作步骤与对象操作的对应 + 教程配图引用
     - 保持模板的扁平化风格和emoji图标
     - 参考 [html-structure-guide.md](references/html-structure-guide.md) 中的图片使用规范
     - 在标题区域添加教程链接，方便用户对比学习

- 可选分支：
  - 当教程包含多个操作流程时：为每个流程生成独立的逻辑板块和流程图
  - 当对象关系复杂时：生成多个Mermaid图展示不同视角（类图、ER图、数据流图）
  - 当用户提供了教程配图时：在过程板块引用配图，使讲解更贴合原文
  - 当操作流程较长时：生成详细流程图，标注决策节点和数据转换

## 资源索引
- 分析方法：见 [analysis-methodology.md](references/analysis-methodology.md)（教程解析与对象提取方法）
- 分析模板：见 [object-analysis-template.md](references/object-analysis-template.md)（数据对象分析框架）
- 结构说明：见 [html-structure-guide.md](references/html-structure-guide.md)（HTML页面结构说明）
- 页面模板：见 [page-template.html](assets/page-template.html)（可直接使用的HTML完整模板）
- 图表示例：见 [mermaid-diagram-template.md](assets/mermaid-diagram-template.md)（Mermaid图生成示例）

## 注意事项
- 分析对象时，优先从教程中提取官方术语和定义
- **深度知识扩展**：必须对每个核心对象进行联网搜索，获取权威定义和完整知识体系，避免仅依赖教程内容
- **教程原文引用**：在对象卡片中适当引用原教程的关键内容，保持原文表述的准确性，用于对比学习
- 对象关系图应清晰展示层次结构（使用 classDiagram 或 graph TD）
- HTML页面需保持清新扁平风格，使用emoji增强可读性
- **图片引用**：当用户提供教程配图时，在对应操作步骤后引用图片，增强可读性
- **教程链接**：在页面标题区域添加原教程链接按钮，方便用户打开对比学习
- 业务逻辑推导要基于对象关系，避免凭空想象
- 所有内容应形成"原理→逻辑→过程"的完整认知链条

## 使用示例

### 示例1：ArcGIS Pro 地图制作
- **功能说明**：将ArcGIS Pro地图布局教程转化为结构化HTML
- **执行方式**：智能体分析 + 使用模板生成HTML
- **关键对象**：工程（Project）、布局（Layout）、地图框（MapFrame）、地图（Map）、图层（Layer）、要素（Feature）
- **业务逻辑**：工程管理资源 → 地图框承载地图视图 → 布局编排所有元素 → 图层叠加生成地图

### 示例2：Photoshop 图像处理
- **功能说明**：分析PS操作背后的数据对象和逻辑
- **执行方式**：智能体分析 + 使用模板生成HTML
- **关键对象**：文档（Document）、图层（Layer）、通道（Channel）、蒙版（Mask）、滤镜（Filter）
- **业务逻辑**：图层叠加管理像素数据 → 蒙版控制透明度 → 滤镜处理像素值

### 示例3：Excel 数据分析
- **功能说明**：解析Excel数据透视表的对象结构
- **执行方式**：智能体分析 + 使用模板生成HTML
- **关键对象**：工作簿（Workbook）、工作表（Worksheet）、单元格（Cell）、数据透视表（PivotTable）、字段（Field）
- **业务逻辑**：源数据区域 → 字段拖拽定义维度/度量 → 聚合计算生成报表
