# kb-source-organizer · 数据源整理师

把任意主题（课程 / 学科 / 产品 / 领域）整理为**体系化、可可视化**的知识体系数据源：
先产出 5 份 KSB-YAML，再校验合并为「完整详细的 Consolidated JSON」，供四视图前端（图谱 / 思维导图 / 矩阵 / 学习路线）消费。

> 这是一份 WorkBuddy 用户级技能。把它放到 `~/.workbuddy/skills/kb-source-organizer/`（Windows：`C:\Users\<你>\.workbuddy\skills\kb-source-organizer\`）即可被 WorkBuddy 自动识别加载。

## 它能根治什么

| 前端缺陷 | 数据源根因 | 本技能的强制约束 |
|---------|-----------|----------------|
| 侧边栏无树状结构 | 缺 parent 树 | 单一根 + 无环树 + 深度≤4 + 输出 children |
| 节点字号无层次 | importance 全相同 | importance 必须区分（0.5–1.0）+ 水平分布 1–4 |
| 矩阵看不懂 | 维度无语义 | 每个维度必须写 `purpose` |
| 学习路线重复项 | 阶段内 KP 重复 | 阶段内唯一 + 跨阶段复用标记 sharedNodeIds |

## 目录结构

```
kb-source-organizer/
├── SKILL.md                       # 技能入口（触发词 + 工作流）
├── README.md                      # 本文件
├── references/
│   ├── ksb-yaml-system-prompt.md  # 细化版 system prompt（直接给 LLM 当 system）
│   └── data-model.md              # 数据模型规范 + 常见失败修复表
├── scripts/
│   └── validate_kb.py             # 五文件校验 + 合并为 Consolidated JSON
├── schema/
│   └── ksb-yaml.schema.json       # Consolidated JSON 的 JSON Schema（Draft 2020-12）
└── examples/
    └── remote-sensing/            # 开箱示例：遥感智能计算（5 YAML + 合并结果）
        ├── domain.yaml
        ├── dimensions.yaml
        ├── relation_types.yaml
        ├── knowledge_points.yaml
        ├── scenarios.yaml
        └── kb-consolidated.json
```

## 依赖安装

```bash
pip install pyyaml          # 必装：YAML 解析（硬依赖）
pip install jsonschema      # 可选：--check-schema 用（缺则跳过校验并提示）
```

WorkBuddy 托管运行时若未装 PyYAML：

```bash
C:\Users\admin\.workbuddy\binaries\python\versions\3.13.12\python.exe -m pip install pyyaml jsonschema
```

## 使用流程

1. **收集主题与素材**（大纲 / 课件 / 资料）。
2. **生成 5 份 YAML**：把 `references/ksb-yaml-system-prompt.md` 设为 LLM 的 system prompt，主题与素材作为 user 消息，让它输出 5 个 YAML 代码块（domain / dimensions / relation_types / knowledge_points / scenarios）。
3. **校验 + 合并**：
   ```bash
   python scripts/validate_kb.py <目录> --emit-json <目录>/kb-consolidated.json --check-schema
   ```
   校验器强制单根 / 无环 / 度量区分 / 维度 purpose / 场景去重，失败会逐条列出。
4. **交付**：把 `kb-consolidated.json` 导入四视图前端即可渲染。

## 跑示例（验证安装）

```bash
python scripts/validate_kb.py examples/remote-sensing --emit-json examples/remote-sensing/kb-consolidated.json --check-schema
# 期望：节点 28 / 关系 89 / 路线 3 / ✓ JSON Schema 校验通过
```

## 命名约定

- YAML 用 snake_case（AI 友好）：`line_style` / `learning_path_behavior` / `knowledge_points` / `key_dependencies`
- Consolidated JSON 用 camelCase（JS 友好）：`lineStyle` / `learningPathBehavior` / `knowledgePoints` / `keyDependencies`
- 转换在 `validate_kb.py` 合并层自动完成，无需手动转。
