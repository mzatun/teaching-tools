---
name: kb-source-organizer
description: Use this skill when a user wants to organize any topic into a systematic, visualization-ready knowledge system. It produces well-structured KSB-YAML (single-root hierarchy tree, differentiated importance/metrics, semantic dimensions with purpose, deduplicated learning paths) and converts it to a detailed Consolidated JSON for four-view frontends (graph / mindmap / matrix / learning route). Triggers include "整理知识体系", "生成某专题的知识图谱数据", "把主题变成结构化 YAML/JSON", "知识体系数据源/整理技能", or any request to model a domain's knowledge structure before visualization.
agent_created: true
---

# Kb Source Organizer（数据源整理师）

将任意主题整理为**体系化、可可视化**的知识体系数据源：先产出 5 份 KSB-YAML，再校验合并为"完整详细的 Consolidated JSON"，供四视图前端消费。

## When to use
- 用户要为一个主题（课程、学科、产品、领域）建立结构化知识体系的**数据**（而非直接画前端）。
- 用户反馈"数据不够体系化 / 树状结构缺失 / 矩阵看不懂 / 路线重复"等可视化缺陷，需要先修数据源。
- 用户要复现"AI 辅助构建可视化知识体系"类平台的数据生成环节。

## Workflow

### Step 1 — 收集主题与素材
向用户确认主题，并尽可能获取参考资料（大纲、课件要点、资料文本、已知关键内容）。资料越充分，产出越准。

### Step 2 — 生成 5 份 KSB-YAML
加载 `references/ksb-yaml-system-prompt.md` 作为系统提示词，把主题与素材作为用户指令发给建模引擎（任意支持长输出的 LLM，或自己扮演该引擎）。
强制纪律（详见 `references/data-model.md`）：
- **单一根 + 树**：仅一个 `parent:null` 节点，`parent` 成树、无环、深度≤4。
- **度量区分**：`importance` 在节点间明显拉开（0.5-1.0），`level` 分布 1-4。
- **维度语义**：每个维度写 `purpose`。
- **场景去重**：同阶段 `knowledge_points` 唯一，跨阶段复用允许（标记 shared）。

### Step 3 — 校验并合并为详细 JSON
把 5 份 YAML 存入目录，运行技能内置校验器：
```bash
python scripts/validate_kb.py <目录> --emit-json <目录>/kb-consolidated.json --check-schema
```
- 校验器强制本体论体系化约束（单根/无环/度量区分/维度 purpose/场景去重），失败会逐条列出。
- 通过后输出 `kb-consolidated.json`，含 `dimensions`(带 purpose)、`nodes`(带 parent/children/metrics)、`links`(七关系)、`scenarios`(带 sharedNodeIds)。

### Step 4 — 交付与下游
- 把 `kb-consolidated.json` 导入四视图前端（图谱/思维导图/矩阵/学习路线）即可渲染。
- 如用户要新建前端或复用既有 HTML，参考 `references/data-model.md` 的第八节"常见失败与修复"。

## Resources
- `references/ksb-yaml-system-prompt.md` — 细化版系统提示词（强制层级/度量/维度/场景纪律），Step 2 直接用作 system prompt。
- `references/data-model.md` — 数据模型规范与常见失败修复，Step 2/4 的权威参考。
- `scripts/validate_kb.py` — 五文件校验 + 合并为 Consolidated JSON（含树完整性、度量区分度、维度 purpose、场景去重检查）。
- `schema/ksb-yaml.schema.json` — Consolidated JSON 的 JSON Schema（Draft 2020-12）。

## 依赖与环境
- **必装** `pip install pyyaml`：YAML 解析是硬依赖，缺失会直接报错退出。
- **可选** `pip install jsonschema`：`--check-schema` 使用；缺失则跳过 Schema 校验并提示，不影响合并。
- **WorkBuddy 托管运行时**（managed runtime）若未装 PyYAML，请在该运行时内安装：
  `C:\Users\admin\.workbuddy\binaries\python\versions\3.13.12\python.exe -m pip install pyyaml jsonschema`
  （或先建 venv 再装，见 WorkBuddy 运行时说明）。
- **已自带示例**：本技能 `examples/remote-sensing/` 含 5 份 YAML + 合并结果 `kb-consolidated.json`，可直接验证：
  `python scripts/validate_kb.py examples/remote-sensing --emit-json examples/remote-sensing/kb-consolidated.json --check-schema`

## Notes
- YAML 用 snake_case（AI 友好），JSON 用 camelCase（JS 友好），转换在 `validate_kb.py` 合并层完成。
- 命名约定：`id_prefix` 用小写短前缀避免跨专题 id 冲突；`id` 用全局唯一英文短 id。
