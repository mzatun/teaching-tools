# KSB-YAML 数据模型（kb-source-organizer 强化版）

把"主题"整理为可被四视图前端消费的体系化数据。两阶段闭环：
**主题 + 参考资料 → AI 按本规范产出 5 份 YAML → validate_kb.py 校验+合并 → Consolidated JSON → 四视图**。

## 一、五份 YAML 与职责
| 文件 | 职责 | 关键字段 |
|------|------|---------|
| domain.yaml | 主题元信息 | id_prefix, name, description, audience |
| dimensions.yaml | 多维分类维度（矩阵轴） | name, **purpose(必填)**, values[id,name,color] |
| relation_types.yaml | 七种语义关系样式 | type, name, learning_path_behavior, visual |
| knowledge_points.yaml | 知识点（树+度量+关系） | id, name, level, **parent**, layer, tags, metrics, relations |
| scenarios.yaml | 学习/应用路线 | id, name, role, total_time, phases[name, knowledge_points, key_dependencies] |

## 二、层级树（根治"侧边栏无树状结构"）
- 单一根：`parent: null`（通常 level=1，领域总览）。
- 其余节点 `parent` 指向已存在父 id；整棵**单根、无环、深度≤4**。
- level 语义固定：1=总览 / 2=分支模块 / 3=核心概念 / 4=实体·细节·工具。
- 合并后每个节点带 `children`（子 id 列表），前端据此建可折叠树。

## 三、度量（根治"字号/重要性无层次"）
- `importance` 0-1，**节点间必须区分**（根/核心 0.9-1.0，分支 0.7-0.85，细节 0.5-0.7）。
- `difficulty` 1-5；`study_time` 正整数（分钟）；`hub_score` 可选（枢纽节点 0.8+）。
- 校验器会拒绝"所有 importance 相同 / 所有 level 相同"。

## 四、维度与矩阵（根治"矩阵看不懂"）
- 每个维度必须写 `purpose`：解释这一轴衡量什么、怎么用。前端矩阵据此生成标题与图例。
- `tags` 以"维度名→值id"映射到维度取值；矩阵即"维度A×维度B"交叉，格子内是该交集中的知识点。
- 建议维度：知识领域 / 学习阶段 / 能力类型 / 应用场景（至少 2 个，供行列选择）。

## 五、场景路线（根治"路线重复项"）
- 每个 phase 内 `knowledge_points` **唯一**；跨 phase 复用允许，合并时计算 `sharedNodeIds` 供前端标 `shared`。
- `key_dependencies` 用 `A->B` 表达学习先后，必须合法。
- 合并后 scenarios 每项含 `phases[].knowledgePoints` 与 `sharedNodeIds`。

## 六、Consolidated JSON（前端消费格式）
扩展 knowledge-graph 4 键（title/nodes/links/categories）+：
- `dimensions[]`: 含 `purpose` 与 `values[]`
- `nodes[]`: 含 `parent` / `children` / `level` / `layer` / `tags` / `importance` / `difficulty` / `studyTime` / `hubScore`
- `links[]`: 含 `type`(七关系) / `weight` / `label` / `visual`
- `scenarios[]`: 含 `phases[].knowledgePoints` / `sharedNodeIds` / `role` / `totalTime`

## 七、命名约定
- YAML 用 snake_case（AI 友好）：line_style, learning_path_behavior, knowledge_points, key_dependencies...
- Consolidated JSON 用 camelCase（JS 友好）：lineStyle, learningPathBehavior, knowledgePoints, keyDependencies...
- 转换在 validate_kb.py 的合并层完成，AI/用户无需手动转。

## 八、常见失败与修复
| 校验报错 | 原因 | 修复 |
|---------|------|------|
| 根节点多于一个 | 多个 parent:null | 只留一个根，其余挂到根下 |
| 检测到父子环路 | parent 互指 | 打断环，改为单向树 |
| 所有节点 importance 相同 | 全写 0.8 | 按层级拉开 0.5-1.0 |
| 维度[..]缺少 purpose | 漏写 | 补 purpose 说明 |
| 阶段[..]内 knowledge_points 有重复 | 同 phase 列两次 | 去重，跨阶段复用靠 shared |
| tags 值不在维度取值中 | 维度名/值对不上 | 对齐 dimensions.yaml |
