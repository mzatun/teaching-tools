#!/usr/bin/env python3
"""validate_kb.py — KSB-YAML 数据源整理校验器（kb-source-organizer 技能内核）

校验 KSB-YAML 五文件（结构 / 跨引用 / 关系合法性 / 本体论体系化约束），
并可合并为 Consolidated JSON 供前端四视图消费，可选 JSON Schema 校验。

用法:
  python validate_kb.py <目录> [--emit-json out.json] [--check-schema]

体系化强制项（根治"数据不够体系化"）：
  · 树完整性：单一根节点（parent:null）、无父子环路、parent 必存在
  · 层级区分：节点必须分布在多个 level（1-4），不能全平铺
  · 度量区分：importance 不能全部相同（否则字号/重要性无层次）
  · 维度语义：每个维度必须写 purpose（矩阵横纵轴解释依赖它）
  · 场景去重：同一阶段内 knowledge_points 必须唯一（跨阶段复用允许，标记 shared）
"""
import sys, os, json, argparse
from collections import Counter

try:
    import yaml
except ImportError:
    sys.exit("缺少 PyYAML：请运行  pip install pyyaml jsonschema")

REQUIRED_FILES = ["domain.yaml", "dimensions.yaml", "relation_types.yaml",
                  "knowledge_points.yaml", "scenarios.yaml"]
RELATION_TYPES = {"depends", "constrains", "contains", "extends", "evolved", "analogy", "contrast"}
LEARNING_BEHAVIORS = {"reverse", "keep_direction", "keep_as_reference"}
LINE_STYLES = {"solid", "dashed", "dotted"}
LAYERS = {"scene", "concept", "entity"}

errs = []

def err(msg):
    global errs
    errs.append(msg)
    print("  ✗ " + msg)

def load_yaml(path):
    with open(path, encoding="utf-8") as f:
        return yaml.safe_load(f)

def build_consolidated(domain, dims, rts, kps, scs):
    d = domain.get("domain", {})
    first_dim = (dims.get("dimensions") or [{}])[0]
    categories = [{"id": v["id"], "name": v.get("name", v["id"]), "color": v.get("color", "#999")}
                  for v in first_dim.get("values", [])]
    # 维度（带 purpose，用于矩阵横纵轴解释）
    dims_out = []
    for dim in dims.get("dimensions", []):
        dim_out = {"name": dim.get("name"), "purpose": dim.get("purpose", "")}
        dim_out["values"] = [{"id": v["id"], "name": v.get("name", v["id"]), "color": v.get("color", "#999")}
                             for v in dim.get("values", [])]
        dims_out.append(dim_out)
    rt_visual = {}
    for rt in rts.get("relations", []):
        if not rt.get("type"):
            continue
        v = rt.get("visual", {})
        rt_visual[rt["type"]] = {
            "color": v.get("color"),
            "lineStyle": v.get("line_style"),
            "arrow": v.get("arrow"),
        }
    nodes, links = [], []
    for kp in kps.get("knowledge_points", []):
        tags = kp.get("tags", {})
        primary_cat = tags.get(first_dim.get("name")) if first_dim.get("name") else None
        m = kp.get("metrics", {})
        node = {
            "id": kp["id"], "label": kp.get("name", kp["id"]),
            "category": primary_cat or (categories[0]["id"] if categories else "core"),
            "level": kp.get("level", 3), "parent": kp.get("parent"),
            "layer": kp.get("layer"), "tags": tags,
            "definition": kp.get("definition"), "description": kp.get("description"),
            "examples": kp.get("examples", []), "keyPoints": kp.get("keyPoints", []),
            "importance": m.get("importance", 0.5), "difficulty": m.get("difficulty", 3),
            "studyTime": m.get("study_time", 30),
        }
        if m.get("hub_score") is not None:
            node["hubScore"] = m["hub_score"]
        nodes.append(node)
        for rel in kp.get("relations", []):
            link = {
                "source": kp["id"], "target": rel.get("target"),
                "type": rel.get("type"), "weight": rel.get("weight", 0.5),
                "visual": rt_visual.get(rel.get("type"), {}),
            }
            if rel.get("note"):
                link["label"] = rel["note"]
            links.append(link)
    # 子节点映射（侧边栏树）
    child_map = {}
    for nd in nodes:
        p = nd.get("parent")
        if p:
            child_map.setdefault(p, []).append(nd["id"])
    for nd in nodes:
        if nd["id"] in child_map:
            nd["children"] = child_map[nd["id"]]
    scenarios_out = []
    for sc in scs.get("scenarios", []):
        so = {"name": sc.get("name"), "phases": []}
        if sc.get("role"):
            so["role"] = sc["role"]
        if sc.get("total_time"):
            so["totalTime"] = sc["total_time"]
        # 跨阶段复用节点（路线视图标记 shared）
        cnt = Counter()
        for ph in sc.get("phases", []):
            for k in ph.get("knowledge_points", []):
                cnt[k] += 1
        shared = {k for k, c in cnt.items() if c > 1}
        for ph in sc.get("phases", []):
            po = {"name": ph.get("name"), "knowledgePoints": ph.get("knowledge_points", [])}
            if ph.get("key_dependencies"):
                po["keyDependencies"] = ph["key_dependencies"]
            so["phases"].append(po)
        so["sharedNodeIds"] = sorted(shared)
        scenarios_out.append(so)
    return {
        "title": d.get("name", ""), "subtitle": d.get("description", ""),
        "dimensions": dims_out, "categories": categories,
        "nodes": nodes, "links": links, "scenarios": scenarios_out,
    }

def validate_kb(dirpath):
    for fn in REQUIRED_FILES:
        if not os.path.exists(os.path.join(dirpath, fn)):
            err(f"缺少文件: {fn}")
    if errs:
        return None

    domain = load_yaml(os.path.join(dirpath, "domain.yaml")) or {}
    dims = load_yaml(os.path.join(dirpath, "dimensions.yaml")) or {}
    rts = load_yaml(os.path.join(dirpath, "relation_types.yaml")) or {}
    kps = load_yaml(os.path.join(dirpath, "knowledge_points.yaml")) or {}
    scs = load_yaml(os.path.join(dirpath, "scenarios.yaml")) or {}

    d = domain.get("domain", {})
    if not d.get("id_prefix"): err("domain.id_prefix 缺失")
    if not d.get("name"): err("domain.name 缺失")
    if not d.get("description"): err("domain.description 缺失")

    dim_map = {}
    for dim in dims.get("dimensions", []):
        dn = dim.get("name")
        if not dn: err("dimensions 中存在无 name 的维度"); continue
        if not dim.get("purpose"): err(f"维度[{dn}] 缺少 purpose 说明（用于矩阵横纵轴解释，必须填写）")
        ids = set()
        for v in dim.get("values", []):
            if not v.get("id"): err(f"维度[{dn}] 取值缺 id")
            if not v.get("name"): err(f"维度[{dn}] 取值缺 name")
            col = v.get("color", "")
            if not (isinstance(col, str) and col.startswith("#") and len(col) == 7):
                err(f"维度[{dn}] 取值 {v.get('id')} 颜色格式错误: {col}")
            ids.add(v.get("id"))
        dim_map[dn] = ids

    rt_types = set()
    for rt in rts.get("relations", []):
        t = rt.get("type")
        if not t: err("relation_types 中存在无 type 的关系"); continue
        rt_types.add(t)
        if t not in RELATION_TYPES: err(f"未知关系 type: {t}（必须是七种之一）")
        if rt.get("learning_path_behavior") not in LEARNING_BEHAVIORS:
            err(f"关系 {t} learning_path_behavior 非法: {rt.get('learning_path_behavior')}")
        if rt.get("visual", {}).get("line_style") not in LINE_STYLES:
            err(f"关系 {t} line_style 非法: {rt.get('visual', {}).get('line_style')}")

    kp_ids = set()
    for kp in kps.get("knowledge_points", []):
        kid = kp.get("id")
        if not kid: err("knowledge_points 中存在无 id 的节点"); continue
        kp_ids.add(kid)
        if not kp.get("name"): err(f"{kid}: name 缺失")
        lv = kp.get("level")
        if not isinstance(lv, int) or lv < 1 or lv > 4: err(f"{kid}: level 应为 1-4 整数")
        if kp.get("layer") not in LAYERS: err(f"{kid}: layer 非法: {kp.get('layer')}")
        tags = kp.get("tags", {})
        if not tags: err(f"{kid}: tags 为空")
        for dn, vid in tags.items():
            if dn not in dim_map: err(f"{kid}: tags 维度 {dn} 未在 dimensions 定义")
            elif vid not in dim_map[dn]: err(f"{kid}: tags 值 {vid} 不在维度 {dn} 取值中")
        if not kp.get("definition"): err(f"{kid}: definition 缺失")
        if not kp.get("description"): err(f"{kid}: description 缺失")
        m = kp.get("metrics", {})
        if not isinstance(m.get("difficulty"), int) or not (1 <= m.get("difficulty") <= 5):
            err(f"{kid}: metrics.difficulty 应为 1-5")
        imp = m.get("importance")
        if not isinstance(imp, (int, float)) or not (0 <= imp <= 1):
            err(f"{kid}: metrics.importance 应为 0-1")
        if not isinstance(m.get("study_time"), int) or m.get("study_time") <= 0:
            err(f"{kid}: metrics.study_time 应为正整数")
        for rel in kp.get("relations", []):
            if rel.get("type") not in RELATION_TYPES: err(f"{kid}: relation type {rel.get('type')} 非法")
            w = rel.get("weight")
            if not isinstance(w, (int, float)) or not (0 <= w <= 1): err(f"{kid}->{rel.get('target')}: weight 应为 0-1")

    for kp in kps.get("knowledge_points", []):
        kid = kp.get("id")
        if kid is None: continue
        parent = kp.get("parent")
        if parent is not None and parent not in kp_ids: err(f"{kid}: parent {parent} 不存在")
        for rel in kp.get("relations", []):
            if rel.get("target") not in kp_ids: err(f"{kid}-> 关系目标 {rel.get('target')} 不存在")

    # —— 树完整性：单根 + 无环（根治"侧边栏无树状结构"）——
    pkps = kps.get("knowledge_points", [])
    parent_map = {kp.get("id"): kp.get("parent") for kp in pkps if kp.get("id")}
    roots = [i for i, p in parent_map.items() if p is None]
    if len(roots) == 0:
        err("缺少根节点（parent 为 null 的顶层节点）")
    elif len(roots) > 1:
        err(f"根节点多于一个（{roots}），必须单一根以构建知识体系树")
    for start in parent_map:
        seen = set(); cur = parent_map.get(start)
        while cur is not None:
            if cur == start or cur in seen:
                err(f"检测到父子环路，涉及节点 {start}"); break
            seen.add(cur); cur = parent_map.get(cur)

    for sc in scs.get("scenarios", []):
        if not sc.get("name"): err("scenario 缺 name")
        for ph in sc.get("phases", []):
            kp_list = ph.get("knowledge_points", [])
            if len(kp_list) != len(set(kp_list)):
                err(f"scenario[{sc.get('name')}] 阶段[{ph.get('name')}] 内 knowledge_points 有重复（同阶段节点必须唯一）")
            for kpid in kp_list:
                if kpid not in kp_ids: err(f"scenario[{sc.get('name')}]: 节点 {kpid} 不存在")
            for dep in ph.get("key_dependencies", []):
                if "->" not in dep: err(f"scenario[{sc.get('name')}]: 依赖格式错误 {dep}"); continue
                a, b = dep.split("->")
                if a not in kp_ids: err(f"scenario: 依赖起点 {a} 不存在")
                if b not in kp_ids: err(f"scenario: 依赖终点 {b} 不存在")

    nodes = kps.get("knowledge_points", [])
    n = len(nodes)
    total_rel = sum(len(kp.get("relations", [])) for kp in nodes)
    avg_deg = (total_rel * 2) / n if n else 0
    if avg_deg < 2: err(f"平均度数 {avg_deg:.2f} < 2（图谱偏稀疏）")
    isolated = [kp.get("id") for kp in nodes if not kp.get("relations") and kp.get("parent") is None]
    iso_ratio = len(isolated) / n if n else 0
    if iso_ratio > 0.05: err(f"孤岛节点比例 {iso_ratio:.0%} > 5%")

    # —— 度量区分度（根治"字号/重要性无层次"）——
    imps = [kp.get("metrics", {}).get("importance") for kp in nodes
            if isinstance(kp.get("metrics", {}).get("importance"), (int, float))]
    if imps and len({round(v, 2) for v in imps}) == 1:
        err(f"所有节点 importance 相同（{imps[0]}），缺乏区分度，图谱字号/重要性无法体现层次")
    levels = {kp.get("level") for kp in nodes}
    if len(levels) < 2:
        err(f"所有节点 level 相同（{sorted(levels)}），缺乏层级区分（应有 1-4 多层级）")

    return build_consolidated(domain, dims, rts, kps, scs)

def main():
    global errs
    ap = argparse.ArgumentParser()
    ap.add_argument("dir", help="包含五文件 YAML 的目录")
    ap.add_argument("--emit-json", help="输出合并后的 Consolidated JSON 路径", default=None)
    ap.add_argument("--check-schema", action="store_true", help="用 JSON Schema 校验合并结果")
    args = ap.parse_args()
    errs = []
    print(f"校验目录: {args.dir}")
    consolidated = validate_kb(args.dir)
    if args.emit_json and consolidated is not None:
        with open(args.emit_json, "w", encoding="utf-8") as f:
            json.dump(consolidated, f, ensure_ascii=False, indent=2)
        print(f"  已写出 Consolidated JSON: {args.emit_json}")
    if args.check_schema and consolidated is not None:
        try:
            from jsonschema import Draft202012Validator
            schema_path = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                        "..", "schema", "ksb-yaml.schema.json")
            with open(schema_path, encoding="utf-8") as f:
                schema = json.load(f)
            Draft202012Validator(schema).validate(consolidated)
            print("  ✓ JSON Schema 校验通过")
        except ImportError:
            print("  ⚠ 未安装 jsonschema，跳过 schema 校验（pip install jsonschema）")
        except Exception as e:
            err(f"Schema 校验失败: {e}")
    print("-" * 40)
    if errs:
        print(f"结果: 失败，{len(errs)} 个问题")
        for e in errs:
            print("  - " + e)
        sys.exit(1)
    else:
        n_nodes = len(consolidated["nodes"])
        n_links = len(consolidated["links"])
        n_sc = len(consolidated["scenarios"])
        print(f"统计: 节点 {n_nodes} / 关系 {n_links} / 路线 {n_sc}")
        print("结果: ✓ 通过（结构 / 跨引用 / 关系 / 体系化约束全部合规）")

if __name__ == "__main__":
    main()
