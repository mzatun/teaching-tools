---
name: docx-template-generator
description: "根据Word模板自动填充内容并生成新文档。触发词：生成Word报告、填充模板、按模板生成文档、docx template、word report。"
---

# docx-template-generator

根据用户上传的Word模板（.docx），自动识别占位符、生成内容、填充模板并返回下载链接。

## When to Use

✅ **USE this skill when:**

- 用户提供Word模板文件，要求按模板生成报告
- 用户指定主题，需要自动填充模板内容
- 用户说"按模板生成"、"填充模板"、"生成报告"等

## When NOT to Use

❌ **DON'T use this skill when:**

- 用户只是想阅读或查看Word文档内容
- 用户没有提供模板文件

## Dependencies

```bash
pip install python-docx requests
```

## Workflow

### Step 1: 读取模板，识别占位符

首先读取用户上传的Word模板，动态识别所有 `{{占位符}}`：

```python
from docx import Document
import re

def extract_placeholders(doc_path):
    """提取Word文档中所有的占位符"""
    doc = Document(doc_path)
    placeholders = set()
    
    # 从段落中提取
    for para in doc.paragraphs:
        found = re.findall(r'\{\{[^}]+\}\}', para.text)
        placeholders.update(found)
    
    # 从表格中提取
    for table in doc.tables:
        for row in table.rows:
            for cell in row.cells:
                found = re.findall(r'\{\{[^}]+\}\}', cell.text)
                placeholders.update(found)
    
    return list(placeholders)

# 使用示例
placeholders = extract_placeholders('template.docx')
print(f"发现的占位符: {placeholders}")
```

### Step 2: 根据主题生成内容

**关键步骤：AI根据用户提供的主题，为每个占位符生成高质量内容**

内容生成原则：
- 根据占位符名称推断内容类型（如"背景"、"目标"、"成果"等）
- 结合主题生成专业、具体的内容
- 使用分条列举、数据支撑增强说服力
- 保持内容逻辑连贯、层次清晰

常见占位符类型及内容建议：

| 占位符关键词 | 内容建议 |
|-------------|---------|
| 标题/题目 | 直接使用用户提供的主题 |
| 部门/单位 | 根据主题推断相关部门 |
| 姓名/作者 | 可询问用户或使用默认值 |
| 日期 | 使用当前日期 |
| 背景/概述 | 介绍主题相关的行业背景、技术发展、政策环境 |
| 目标/目的 | 列出3-5项具体、可衡量的目标 |
| 内容/工作 | 详细描述具体工作，分条列出 |
| 成果/数据 | 提供量化数据和关键成果 |
| 问题/挑战 | 客观分析当前面临的困难，3-5条 |
| 措施/建议 | 针对问题提出可行的解决方案 |
| 计划/展望 | 列出后续工作安排，3-5项 |
| 附件 | 相关附件文件名或"无" |

### Step 3: 填充模板

```python
from docx import Document
from datetime import datetime

def fill_template(template_path, replacements, output_path):
    """填充Word模板"""
    doc = Document(template_path)
    
    # 替换段落中的占位符
    for para in doc.paragraphs:
        for old, new in replacements.items():
            if old in para.text:
                para.text = para.text.replace(old, new)
    
    # 替换表格中的占位符
    for table in doc.tables:
        for row in table.rows:
            for cell in row.cells:
                for old, new in replacements.items():
                    if old in cell.text:
                        cell.text = cell.text.replace(old, new)
    
    doc.save(output_path)
    return output_path

# 使用示例
replacements = {
    '{{报告标题}}': 'AI智能体研究报告',
    '{{部门}}': '人工智能研究部',
    '{{日期}}': datetime.now().strftime('%Y年%m月%d日'),
    # ... AI根据主题为每个占位符生成内容
}

fill_template('template.docx', replacements, 'output.docx')
```

### Step 4: 上传并返回下载链接

使用Uploader skill上传生成的文档：

```bash
python3 /root/.openclaw/workspace/skills/uploader/scripts/upload_media.py '/path/to/output.docx'
```

## Complete Example

用户上传模板后，AI执行完整流程：

```python
#!/usr/bin/env python3
"""
完整示例：根据模板生成AI智能体研究报告
"""
from docx import Document
from datetime import datetime
import re

# 1. 加载模板
template_path = '/root/.openclaw/workspace/work_report_template.docx'
doc = Document(template_path)

# 2. 动态识别占位符
placeholders = set()
for para in doc.paragraphs:
    placeholders.update(re.findall(r'\{\{[^}]+\}\}', para.text))
for table in doc.tables:
    for row in table.rows:
        for cell in row.cells:
            placeholders.update(re.findall(r'\{\{[^}]+\}\}', cell.text))

print(f"发现的占位符: {sorted(placeholders)}")

# 3. 根据主题"AI智能体研究报告"生成内容
topic = "AI智能体研究报告"
replacements = {
    '{{报告标题}}': topic,
    '{{部门}}': '人工智能研究部',
    '{{姓名}}': 'AI研究团队',
    '{{日期}}': datetime.now().strftime('%Y年%m月%d日'),
    '{{工作背景}}': '''随着大语言模型（LLM）技术的快速发展，AI智能体（AI Agent）成为人工智能领域的重要研究方向。AI智能体是指能够感知环境、自主决策并执行任务的智能系统，具备自主性、反应性、主动性和社交性等特征。2024年以来，以AutoGPT、Claude、GPT-4为代表的大模型智能体技术取得突破性进展，智能体在自动化办公、代码开发、数据分析等领域展现出巨大应用潜力。''',
    '{{工作目标}}': '''1. 系统调研AI智能体的核心技术架构与关键能力
2. 分析国内外主流AI智能体产品的发展现状
3. 评估AI智能体在各行业的应用场景与商业价值
4. 识别AI智能体发展面临的挑战与技术瓶颈''',
    '{{主要工作内容}}': '''1. 技术架构研究：深入分析AI智能体的核心组件
2. 产品调研：对主流智能体产品进行功能对比
3. 应用场景分析：调研各领域实际应用案例
4. 市场研究：收集市场规模数据和竞争格局''',
    '{{工作成果}}': '''• 完成AI智能体技术架构图谱绘制
• 整理国内外20+主流AI智能体产品对比表
• 预测2025-2030年市场规模将保持45%以上年增长率''',
    '{{存在问题}}': '''1. 可靠性问题：复杂任务中存在推理错误
2. 安全风险：自主执行可能带来安全隐患
3. 成本控制：大模型调用成本较高''',
    '{{改进措施}}': '''1. 引入思维链机制提升推理能力
2. 建立多层级安全防护体系
3. 优化模型调用策略降低成本''',
    '{{下一步计划}}': '''1. 深化多智能体协作技术研究
2. 开发面向特定场景的原型系统
3. 选择典型场景进行应用试点''',
    '{{附件}}': '产品对比表.xlsx、技术架构图.png'
}

# 4. 填充模板
for para in doc.paragraphs:
    for old, new in replacements.items():
        if old in para.text:
            para.text = para.text.replace(old, new)

for table in doc.tables:
    for row in table.rows:
        for cell in row.cells:
            for old, new in replacements.items():
                if old in cell.text:
                    cell.text = cell.text.replace(old, new)

# 5. 保存
output_path = '/root/.openclaw/workspace/AI智能体研究报告.docx'
doc.save(output_path)
print(f'文档已保存: {output_path}')
```

然后上传：

```bash
python3 /root/.openclaw/workspace/skills/uploader/scripts/upload_media.py '/root/.openclaw/workspace/AI智能体研究报告.docx'
```

## Notes

1. **动态识别**：不预设占位符列表，从用户模板中动态提取
2. **内容生成**：AI根据占位符名称和主题智能生成内容
3. **格式保留**：直接替换 `para.text` 可能丢失部分格式，复杂模板需遍历 `para.runs`
4. **表格支持**：模板中的表格也会被遍历和替换
5. **文件编码**：确保使用UTF-8编码处理中文
