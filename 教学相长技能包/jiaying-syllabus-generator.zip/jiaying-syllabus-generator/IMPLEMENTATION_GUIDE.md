# 嘉应学院教学大纲生成技能 - 实现指南

本指南详细说明如何实现嘉应学院教学大纲生成技能，包括工作流程、实现步骤和代码示例。

## 核心工作流程

```
用户输入资料 → 资料解析与信息提取 → 内容整合与结构化 → 格式生成(HTML/MD) → 输出文档
```

## 详细实现步骤

### 第一步：接收用户输入

用户需要提供以下信息：

```python
# 输入参数示例
input_data = {
    "course_name": "基于Python的GIS编程",
    "version": "第三版",
    "output_format": "HTML",  # 或 "Markdown"
    "date": "2026-03-29",
    "source_files": {
        "original_syllabus": "原大纲文件路径",
        "teaching_calendar": "教学日历文件路径",
        "experiment_plan": "实验计划文件路径",
        "teaching_process": "教学过程描述文件路径",
        "teaching_strategy": "教学策略文件路径",
        "teaching_tools": "教学工具列表文件路径"
    },
    "team_features": {
        "teaching_style": "AI辅助、案例驱动、实践导向",
        "tools_used": ["Trae AI", "IMA知识库", "图维导图", "QQ群"],
        "collaboration_mode": "教师-学生-AI三方协作",
        "feedback_mechanism": "每周生成学习笔记网页和原理讲解网页"
    }
}
```

### 第二步：资料解析与信息提取

#### 2.1 PDF/Word文档解析

使用markitdown工具解析PDF/Word文档：

```python
from markitdown import MarkItDown

def parse_document(file_path):
    """解析PDF或Word文档"""
    md = MarkItDown()
    result = md.convert(file_path)
    return result.text_content

# 示例：解析原大纲
original_syllabus_text = parse_document(input_data["source_files"]["original_syllabus"])
teaching_calendar_text = parse_document(input_data["source_files"]["teaching_calendar"])
# ... 依次解析其他文件
```

#### 2.2 信息提取

从解析后的文本中提取关键信息：

```python
import re

def extract_course_info(text):
    """提取课程基本信息"""
    info = {}

    # 提取课程名称
    name_pattern = r"课程名称[：:]\s*(.+?)(?:\n|$)"
    match = re.search(name_pattern, text)
    if match:
        info["course_name"] = match.group(1).strip()

    # 提取课程代码
    code_pattern = r"课程代码[：:]\s*(.+?)(?:\n|$)"
    match = re.search(code_pattern, text)
    if match:
        info["course_code"] = match.group(1).strip()

    # 提取学分数
    credit_pattern = r"学分[：:]\s*(\d+\.?\d*)"
    match = re.search(credit_pattern, text)
    if match:
        info["credits"] = match.group(1)

    # 提取学时数
    hours_pattern = r"学时[：:]\s*(\d+\.?\d*)"
    match = re.search(hours_pattern, text)
    if match:
        info["total_hours"] = match.group(1)

    return info

def extract_teaching_objectives(text):
    """提取教学目标"""
    objectives = []

    # 查找教学目标部分
    pattern = r"教学目标[：:]\s*([\s\S]+?)(?=\n\n|课程目标)"
    match = re.search(pattern, text)
    if match:
        objectives_text = match.group(1)
        # 按要点分割
        objectives = [obj.strip() for obj in objectives_text.split('。') if obj.strip()]

    return objectives

def extract_course_content(text):
    """提取教学内容与学时分配"""
    content = []

    # 查找教学内容部分
    pattern = r"教学内容[与及]学时分配[：:]?\s*([\s\S]+?)(?=教学策略|$)"
    match = re.search(pattern, text)
    if match:
        content_text = match.group(1)
        # 解析为列表
        lines = [line.strip() for line in content_text.split('\n') if line.strip()]
        content = lines

    return content

# 提取所有信息
course_info = extract_course_info(original_syllabus_text)
teaching_objectives = extract_teaching_objectives(original_syllabus_text)
course_content = extract_course_content(original_syllabus_text)
experiment_content = extract_experiment_info(teaching_calendar_text)
# ... 依次提取其他信息
```

### 第三步：内容整合与结构化

将提取的信息按照标准结构整合：

```python
def structure_syllabus_data(input_data, extracted_info):
    """按照标准结构组织教学大纲数据"""

    syllabus = {
        "metadata": {
            "course_name": input_data["course_name"],
            "version": input_data["version"],
            "date": input_data["date"]
        },

        "part1": {  # 课程基本信息
            "title": "课程基本信息",
            "content": extracted_info["course_info"]
        },

        "part2": {  # 课程简介与特色
            "title": "课程简介与特色",
            "content": extracted_info["course_intro"]
        },

        "part3": {  # 教学团队与AI协作模式
            "title": "教学团队与AI协作模式",
            "content": {
                "team_style": input_data["team_features"]["teaching_style"],
                "tools_used": input_data["team_features"]["tools_used"],
                "collaboration_mode": input_data["team_features"]["collaboration_mode"]
            }
        },

        "part4": {  # 课程目标与思政目标
            "title": "课程目标与思政目标",
            "content": {
                "teaching_objectives": extracted_info["teaching_objectives"],
                "ideological_objectives": extracted_info["ideological_objectives"]
            }
        },

        # ... 其他部分

        "part10": {  # 十、实验部分
            "title": "十、实验部分",
            "subparts": {
                "experiment_1": {  # 实验项目名称和学时分配
                    "title": "1. 实验项目名称和学时分配",
                    "content": extracted_info["experiment_list"]
                },
                "experiment_2": {  # 实验项目类型
                    "title": "2. 实验项目类型",
                    "content": extracted_info["experiment_types"]
                },
                "experiment_3": {  # 实验项目的具体内容
                    "title": "3. 实验项目的具体内容",
                    "content": extracted_info["experiment_details"]
                },
                "experiment_4": {  # 实验课考核方式
                    "title": "4. 实验课考核方式",
                    "content": extracted_info["experiment_assessment"]
                },
                "experiment_5": {  # 实验指导书以及主要参考书
                    "title": "5. 实验指导书以及主要参考书",
                    "content": extracted_info["experiment_references"]
                }
            }
        },

        # ... 其他部分

        "part14": {  # 编制说明
            "title": "编制说明",
            "content": extracted_info["notes"]
        }
    }

    return syllabus
```

### 第四步：HTML格式生成

#### 4.1 HTML模板

```html
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ course_name }} 教学大纲 {{ version }}</title>
    <style>
        /* CSS样式 */
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>{{ course_name }} 教学大纲</h1>
            <div class="version-badge">{{ version }}</div>
        </header>

        <!-- 各部分内容 -->
        {{ content }}

        <footer>
            <p>编制日期：{{ date }}</p>
        </footer>
    </div>
</body>
</html>
```

#### 4.2 CSS样式（内嵌）

```python
def generate_html_syllabus(syllabus_data):
    """生成HTML格式教学大纲"""

    # CSS样式（基于样例文件的样式）
    css_style = """
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        body {
            font-family: "Microsoft YaHei", "PingFang SC", sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 20px;
            line-height: 1.6;
        }
        .container {
            max-width: 900px;
            margin: 0 auto;
            background: white;
            border-radius: 12px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.15);
            overflow: hidden;
        }
        header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 32px 40px;
            text-align: center;
        }
        header h1 {
            font-size: 28px;
            font-weight: 700;
            margin-bottom: 8px;
        }
        .version-badge {
            display: inline-block;
            background: rgba(255,255,255,0.2);
            padding: 6px 16px;
            border-radius: 20px;
            font-size: 14px;
            font-weight: 600;
            backdrop-filter: blur(10px);
        }
        .main-content {
            padding: 30px 40px;
        }
        .card {
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            border-left: 4px solid #6366f1;
            border-radius: 8px;
            padding: 16px 20px;
            margin-bottom: 16px;
        }
        .card-title {
            font-size: 16px;
            font-weight: 700;
            color: #1e293b;
            margin-bottom: 10px;
            padding-bottom: 6px;
            border-bottom: 2px solid #e2e8f0;
        }
        .card-content p {
            font-size: 14px;
            line-height: 1.7;
            color: #475569;
            margin: 8px 0;
        }
        .card-content strong {
            color: #1e3a8a;
            font-weight: 600;
        }
        .ai-highlight {
            background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%);
            border: 1px solid #f59e0b;
            border-left: 4px solid #d97706;
            border-radius: 6px;
            padding: 12px 16px;
            margin: 10px 0;
            font-size: 13px;
            color: #92400e;
        }
        .ai-highlight::before {
            content: "🤖 AI辅助教学";
            display: block;
            font-weight: 700;
            font-size: 12px;
            color: #b45309;
            margin-bottom: 4px;
        }
        /* 实验项目框样式 */
        .experiment-box {
            background: #f8fbff;
            border: 1px solid #dbeafe;
            border-left: 5px solid #6366f1;
            border-radius: 8px;
            padding: 0;
            margin: 0;
        }
        .experiment-title {
            background: linear-gradient(135deg, #eff6ff 0%, #dbeafe 100%);
            border-bottom: 1px solid #bfdbfe;
            padding: 12px 18px;
            font-size: 14px;
            font-weight: 700;
            color: #1e40af;
        }
        .experiment-content {
            padding: 14px 18px;
        }
        .experiment-content p {
            font-size: 13px;
            line-height: 1.7;
            margin: 0 0 10px 0;
            color: #374151;
        }
        .experiment-content p strong {
            color: #1e3a8a;
            font-weight: 700;
        }
        /* 表格样式 */
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 12px 0;
            font-size: 13px;
        }
        th, td {
            border: 1px solid #cbd5e1;
            padding: 10px 12px;
            text-align: left;
        }
        th {
            background: #f1f5f9;
            font-weight: 600;
            color: #334155;
        }
        /* 列表样式 */
        ul, ol {
            margin: 8px 0;
            padding-left: 24px;
        }
        li {
            font-size: 14px;
            color: #475569;
            margin: 6px 0;
        }
        footer {
            background: #f8fafc;
            border-top: 1px solid #e2e8f0;
            padding: 16px 40px;
            text-align: center;
            font-size: 13px;
            color: #64748b;
        }
    </style>
    """

    # HTML主体
    html_content = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{syllabus_data['metadata']['course_name']} 教学大纲 {syllabus_data['metadata']['version']}</title>
    {css_style}
</head>
<body>
    <div class="container">
        <header>
            <h1>{syllabus_data['metadata']['course_name']} 教学大纲</h1>
            <div class="version-badge">{syllabus_data['metadata']['version']}</div>
        </header>

        <div class="main-content">
"""

    # 生成各部分内容
    for part_key, part_data in syllabus_data.items():
        if part_key.startswith('part') and isinstance(part_data, dict):
            html_content += generate_part_html(part_data)

    html_content += f"""
        </div>
        <footer>
            <p>编制日期：{syllabus_data['metadata']['date']}</p>
        </footer>
    </div>
</body>
</html>
"""

    return html_content

def generate_part_html(part_data):
    """生成单个部分的HTML"""

    html = f"""
    <div class="card">
        <div class="card-title">{part_data['title']}</div>
        <div class="card-content">
"""

    if 'content' in part_data:
        content = part_data['content']

        if isinstance(content, dict):
            # 字典类型内容（如教学目标）
            for key, value in content.items():
                if isinstance(value, list):
                    html += f"<p><strong>{key}：</strong></p>\n<ul>\n"
                    for item in value:
                        html += f"<li>{item}</li>\n"
                    html += "</ul>\n"
                else:
                    html += f"<p><strong>{key}：</strong>{value}</p>\n"

        elif isinstance(content, list):
            # 列表类型内容
            html += "<ul>\n"
            for item in content:
                html += f"<li>{item}</li>\n"
            html += "</ul>\n"

        else:
            # 文本类型内容
            html += f"<p>{content}</p>\n"

    if 'subparts' in part_data:
        # 子部分（如实验部分）
        for subpart_key, subpart_data in part_data['subparts'].items():
            html += generate_part_html(subpart_data)

    html += """
        </div>
    </div>
"""

    return html
```

### 第五步：Markdown格式生成

```python
def generate_markdown_syllabus(syllabus_data):
    """生成Markdown格式教学大纲"""

    md_content = f"""# {syllabus_data['metadata']['course_name']} 教学大纲

**版本**：{syllabus_data['metadata']['version']}
**编制日期**：{syllabus_data['metadata']['date']}

---

"""

    # 生成各部分内容
    for part_key, part_data in syllabus_data.items():
        if part_key.startswith('part') and isinstance(part_data, dict):
            md_content += generate_part_markdown(part_data)
            md_content += "\n---\n\n"

    return md_content

def generate_part_markdown(part_data):
    """生成单个部分的Markdown"""

    md = f"## {part_data['title']}\n\n"

    if 'content' in part_data:
        content = part_data['content']

        if isinstance(content, dict):
            # 字典类型内容
            for key, value in content.items():
                if isinstance(value, list):
                    md += f"**{key}：**\n\n"
                    for item in value:
                        md += f"- {item}\n"
                    md += "\n"
                else:
                    md += f"**{key}：**{value}\n\n"

        elif isinstance(content, list):
            # 列表类型内容
            for item in content:
                md += f"- {item}\n"
            md += "\n"

        else:
            # 文本类型内容
            md += f"{content}\n\n"

    if 'subparts' in part_data:
        # 子部分
        for subpart_key, subpart_data in part_data['subparts'].items():
            md += generate_part_markdown(subpart_data)

    return md
```

### 第六步：输出文件

```python
def save_syllabus(content, output_path):
    """保存教学大纲到文件"""
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(content)

# 示例：输出HTML
if input_data["output_format"] == "HTML":
    html_content = generate_html_syllabus(syllabus_data)
    filename = f"{input_data['course_name']}_教学大纲_{input_data['date']}_v{input_data['version']}.html"
    save_syllabus(html_content, filename)
    print(f"HTML教学大纲已生成：{filename}")

# 示例：输出Markdown
elif input_data["output_format"] == "Markdown":
    md_content = generate_markdown_syllabus(syllabus_data)
    filename = f"{input_data['course_name']}_教学大纲_{input_data['date']}_v{input_data['version']}.md"
    save_syllabus(md_content, filename)
    print(f"Markdown教学大纲已生成：{filename}")
```

## 完整工作流程示例

```python
# 1. 准备输入数据
input_data = {
    "course_name": "基于Python的GIS编程",
    "version": "第三版",
    "output_format": "HTML",
    "date": "2026-03-29",
    # ... 其他输入
}

# 2. 解析所有输入文件
extracted_info = {}
for file_type, file_path in input_data["source_files"].items():
    text = parse_document(file_path)
    extracted_info[file_type] = extract_information(text, file_type)

# 3. 整合为结构化数据
syllabus_data = structure_syllabus_data(input_data, extracted_info)

# 4. 生成文档
if input_data["output_format"] == "HTML":
    final_content = generate_html_syllabus(syllabus_data)
    ext = ".html"
else:
    final_content = generate_markdown_syllabus(syllabus_data)
    ext = ".md"

# 5. 保存文件
output_filename = f"{input_data['course_name']}_教学大纲_{input_data['date']}_v{input_data['version']}{ext}"
save_syllabus(final_content, output_filename)

print(f"教学大纲生成成功：{output_filename}")
```

## 关键注意事项

1. **编码问题**：始终使用UTF-8编码读写文件
2. **正则表达式**：中文正则表达式需要仔细测试
3. **空值处理**：提取不到信息时使用默认值
4. **格式统一**：确保HTML和Markdown输出格式一致
5. **样式内嵌**：HTML的CSS样式内嵌在`<style>`标签中
6. **版本管理**：文件名包含版本号，便于追踪
7. **错误处理**：添加适当的异常处理机制

## 扩展功能建议

1. **批量生成**：支持一次生成多门课程的教学大纲
2. **版本比较**：比较不同版本教学大纲的差异
3. **模板定制**：支持自定义HTML/Markdown模板
4. **格式转换**：HTML↔Markdown互转功能
5. **数据验证**：检查必要信息是否完整
6. **导出Word**：直接导出Word文档格式

---

**本实现指南基于《基于Python的GIS编程》教学大纲的实际生成经验总结而成。**
