# 嘉应学院教学大纲生成技能 - 安装与验证指南

## 📦 技能信息

- **技能名称**：jiaying-syllabus-generator
- **显示名称**：嘉应学院教学大纲生成技能
- **版本**：1.0.0
- **创建日期**：2026-03-29
- **技能路径**：`F:/网易龙虾/.workbuddy/skills/jiaying-syllabus-generator/`

## ✅ 技能文件清单

本技能包含以下6个文件：

```
jiaying-syllabus-generator/
├── SKILL.md                    # 技能定义文件（核心文档）
├── README.md                   # 快速入门指南
├── IMPLEMENTATION_GUIDE.md     # 详细实现指南
├── EXAMPLES.md                 # 使用示例集
├── QUICK_REFERENCE.md         # 快速参考卡片
└── skill.json                  # 技能元数据JSON
```

## 🔍 文件说明

### SKILL.md（核心文档）
- **作用**：定义技能的核心功能、使用流程、输出规范
- **内容**：
  - 技能描述和核心功能
  - 标准教学大纲结构（15部分）
  - 使用流程（4个步骤）
  - 输出规范（HTML/Markdown）
  - 样例参考
  - 技能约束与注意事项
  - 使用场景

### README.md（快速入门）
- **作用**：5分钟快速上手指南
- **内容**：
  - 技能简介和核心特性
  - 适用场景
  - 快速开始（4个步骤）
  - 标准教学大纲结构
  - 样例参考
  - HTML/Markdown版本特点
  - 使用技巧
  - 常见问题

### IMPLEMENTATION_GUIDE.md（实现指南）
- **作用**：详细的技术实现说明
- **内容**：
  - 核心工作流程
  - 详细实现步骤（6个步骤）
  - 完整代码示例（Python）
  - HTML模板和CSS样式
  - Markdown生成逻辑
  - 输出文件处理
  - 关键注意事项
  - 扩展功能建议

### EXAMPLES.md（使用示例）
- **作用**：5个实际使用场景示例
- **内容**：
  - 示例1：完整的HTML格式生成
  - 示例2：Markdown格式生成
  - 示例3：文本直接粘贴输入
  - 示例4：教学大纲版本更新
  - 示例5：多课程批量生成（扩展功能）
  - 常见输出示例
  - 文件输出示例

### QUICK_REFERENCE.md（快速参考）
- **作用**：一页纸快速参考卡片
- **内容**：
  - 一句话描述
  - 输入要求
  - 输出特点
  - 标准结构（15部分）
  - 快速使用模板
  - 文件命名规范
  - 技术要求
  - 常用命令
  - 注意事项

### skill.json（元数据）
- **作用**：技能配置和元数据
- **内容**：
  - 技能基本信息
  - 核心能力列表
  - 支持的格式类型
  - 输入输出类型
  - 依赖关系
  - 使用示例
  - 输出结构
  - 目标用户
  - 使用场景
  - 文档链接
  - 设置选项
  - 约束条件
  - 更新日志

## 🎯 技能验证清单

使用以下清单验证技能是否完整安装：

### ✅ 文件完整性检查
- [ ] SKILL.md 存在且可读
- [ ] README.md 存在且可读
- [ ] IMPLEMENTATION_GUIDE.md 存在且可读
- [ ] EXAMPLES.md 存在且可读
- [ ] QUICK_REFERENCE.md 存在且可读
- [ ] skill.json 存在且格式正确

### ✅ 内容完整性检查（SKILL.md）
- [ ] 技能描述完整
- [ ] 核心功能描述完整（5项）
- [ ] 标准教学大纲结构完整（15部分）
- [ ] 使用流程完整（4个步骤）
- [ ] 输出规范完整
- [ ] 样例参考完整
- [ ] 技能约束完整
- [ ] 使用场景完整

### ✅ JSON格式验证（skill.json）
- [ ] JSON格式有效（可用JSON验证工具检查）
- [ ] 必填字段完整：
  - [ ] name
  - [ ] displayName
  - [ ] version
  - [ ] description
  - [ ] author
  - [ ] created
  - [ ] category
  - [ ] tags
  - [ ] capabilities
  - [ ] documentation
- [ ] 数组字段非空：
  - [ ] tags
  - [ ] capabilities
  - [ ] supported_formats
  - [ ] input_types
- [ ] 日期格式正确（YYYY-MM-DD）

## 🔧 验证步骤

### 步骤1：检查文件存在性
```bash
# PowerShell
cd F:/网易龙虾/.workbuddy/skills/jiaying-syllabus-generator
dir

# 或使用ls命令
ls F:/网易龙虾/.workbuddy/skills/jiaying-syllabus-generator
```

**预期输出**：
```
EXAMPLES.md
IMPLEMENTATION_GUIDE.md
QUICK_REFERENCE.md
README.md
skill.json
SKILL.md
```

### 步骤2：验证JSON格式
```bash
# Python验证JSON格式
python -m json.tool skill.json
```

**预期输出**：格式化后的JSON内容，无错误

### 步骤3：检查文件内容
```bash
# 查看SKILL.md前20行
head -20 SKILL.md

# 查看skill.json前30行
head -30 skill.json
```

**预期输出**：正常显示文件内容

### 步骤4：技能调用测试
向AI智能体发送以下测试指令：

```
请使用【嘉应学院教学大纲生成技能】，生成一个简单的测试教学大纲：

课程名称：测试课程
原大纲：
课程名称：测试课程
课程代码：TEST001
学分：2.0
学时：32
课程简介：这是一个测试课程。

教学团队特色：
- 教学风格：实践导向
- 使用工具：Trae AI、IMA

输出格式：Markdown
版本号：测试版
编制日期：2026-03-29
```

**预期输出**：
```
✅ Markdown教学大纲生成成功！

文件路径：[工作目录]/测试课程_教学大纲_2026-03-29_测试版.md
版本：测试版
格式：Markdown
```

## 🚀 使用技能

### 基本使用

1. **准备资料**：收集6类教学资料（原大纲、教学日历、实验计划、教学过程、教学策略、教学工具）
2. **描述特色**：简要描述教学团队特色
3. **调用技能**：告诉AI智能体使用该技能
4. **获取结果**：等待生成完成，获取HTML或Markdown文件

### 示例调用

```
请使用【嘉应学院教学大纲生成技能】，生成《遥感原理与应用》教学大纲：

1. 原大纲：F:/网易龙虾/遥感原大纲.pdf
2. 教学日历：F:/网易龙虾/遥感教学日历.docx
3. 实验计划：F:/网易龙虾/遥感实验计划.txt
4. 教学过程描述：F:/网易龙虾/遥感教学过程.txt
5. 教学策略：F:/网易龙虾/遥感教学策略.txt
6. 教学工具：ENVI、ArcGIS Pro、Trae AI、IMA

教学团队特色：
- 教学风格：理论扎实、实践丰富、AI辅助
- 使用工具：ENVI、ArcGIS Pro、Trae AI、IMA、图维导图、QQ群
- 协作模式：软件操作-AI辅助-知识沉淀三位一体
- 反馈机制：每周生成实验操作指南和案例解析文档

输出格式：HTML
版本号：第一版
编制日期：2026-03-29
```

## 📚 文档导航

根据您的需求选择合适的文档：

| 需求 | 推荐文档 |
|------|----------|
| **快速上手** | README.md |
| **技术实现** | IMPLEMENTATION_GUIDE.md |
| **实际案例** | EXAMPLES.md |
| **快速查阅** | QUICK_REFERENCE.md |
| **技能定义** | SKILL.md |
| **配置信息** | skill.json |

## 🎓 学习路径

### 初学者路径
1. 阅读 `README.md`（10分钟）
2. 查看 `QUICK_REFERENCE.md`（5分钟）
3. 参考示例1（`EXAMPLES.md`）（10分钟）
4. 实践生成第一个教学大纲（15分钟）

### 进阶用户路径
1. 阅读 `IMPLEMENTATION_GUIDE.md`（30分钟）
2. 研究所有示例（`EXAMPLES.md`）（20分钟）
3. 自定义样式和模板（根据需求）
4. 批量生成多门课程（扩展功能）

### 开发者路径
1. 深入研究 `IMPLEMENTATION_GUIDE.md`
2. 分析代码示例和实现逻辑
3. 修改和扩展技能功能
4. 创建新的输出格式或模板

## 🔗 相关资源

### 样例文件
- HTML样例：`F:/网易龙虾/基于Python的GIS编程_新版教学大纲_2026_v3.html`
- PDF原版：`F:/网易龙虾/2x级 基于Python的GIS编程 教学大纲.pdf`

### 工具文档
- [markitdown文档](https://github.com/microsoft/markitdown)
- [Pandoc文档](https://pandoc.org/)
- [Python官方文档](https://docs.python.org/)

## 🐛 常见问题

### Q1：技能无法调用？
**A**：检查技能是否在正确的目录：`~/.workbuddy/skills/jiaying-syllabus-generator/`

### Q2：JSON格式错误？
**A**：使用 `python -m json.tool skill.json` 验证并修复

### Q3：生成的文件无法打开？
**A**：检查文件编码是否为UTF-8，确保使用正确的软件打开

### Q4：HTML样式不显示？
**A**：确认CSS样式已内嵌在`<style>`标签中

### Q5：Markdown转换失败？
**A**：确保Pandoc已正确安装，使用 `pandoc --version` 检查

## 📞 技术支持

如遇问题，请按以下顺序排查：

1. **查看文档**：检查相关文档是否有解决方案
2. **验证文件**：确保技能文件完整且格式正确
3. **测试调用**：使用简单示例测试技能是否正常
4. **检查环境**：确认Python和依赖工具已正确安装
5. **联系支持**：如仍无法解决，联系开发团队

## ✅ 验证成功标志

当您看到以下所有标志时，说明技能已成功安装并可以使用：

- ✅ 技能目录下有6个文件（SKILL.md、README.md、IMPLEMENTATION_GUIDE.md、EXAMPLES.md、QUICK_REFERENCE.md、skill.json）
- ✅ 所有文件可正常读取
- ✅ skill.json格式有效
- ✅ 可以成功调用技能生成教学大纲
- ✅ 生成的文件可以正常打开和查看

---

**技能安装验证完成！现在您可以开始使用【嘉应学院教学大纲生成技能】了。**
