# ArcGIS Pro 插件生成器 Skill 配置说明

## ✅ 配置状态

**技能名称**: `arcpy-arcgis-pro-plugin-generator`  
**状态**: 已成功配置并可用  
**位置**: `f:\网易龙虾\skills\arcpy-arcgis-pro-plugin-generator\`

## 📁 文件结构

```
f:\网易龙虾\skills\arcpy-arcgis-pro-plugin-generator\
└── SKILL.md  (配置文件)
```

## 🎯 Skill 功能

该 skill 用于生成基于 arcpy 的 ArcGIS Pro 地理脚本插件，可以根据用户输入的 GIS 功能要求，自动生成完整的插件开发包。

### 输出内容

1. **需求分析说明.md** - 详细的功能需求分析
2. **业务逻辑分析.md** - 功能的业务逻辑说明
3. **功能脚本.py** - 完整的 Python 脚本文件（带详细注释）
4. **运行环境说明.md** - ArcGIS Pro 中的配置和调试指南
5. **完整教程.md** - 包含以上所有内容的综合教程

## 🚀 使用方法

### 方法 1: 直接调用

在对话中直接提及需求，例如：

```
请帮我生成一个 ArcGIS Pro 插件，用于计算两个多边形图层的交集，并统计交集中每个多边形的面积。
```

### 方法 2: 显式加载 Skill

```
@skill://arcpy-arcgis-pro-plugin-generator
```

然后按照 skill 指南提供详细的功能需求。

## 📋 输入要求

使用此 skill 时，需要提供详细的 GIS 功能要求，包括：

- ✅ 功能名称和简要描述
- ✅ 预期的输入数据类型（如矢量图层、栅格数据、属性表等）
- ✅ 预期的输出结果（如生成的新图层、统计报告、地图文档等）
- ✅ 所需的交互操作（如参数设置、选择条件、分析范围等）
- ✅ 其他特殊要求（如图层样式、属性计算规则、空间分析方法等）

## ⚙️ 技术配置

### 配置文件格式

该 skill 使用标准的 YAML frontmatter 格式：

```yaml
---
name: "arcpy-arcgis-pro-plugin-generator"
description: "生成基于 arcpy 的 ArcGIS Pro 地理脚本插件。根据用户 GIS 功能要求，生成需求分析、业务逻辑、功能脚本和运行环境说明，并保存到项目文件夹中。"
---
```

### Skill 基础目录

系统会自动将 skill 复制到：
```
C:\Users\admin\.workbuddy\skills\arcpy-arcgis-pro-plugin-generator\
```

## 🔧 故障排除

### 问题 1: Skill 无法加载

**解决方案**: 确认 SKILL.md 文件存在且格式正确，包含正确的 YAML frontmatter。

### 问题 2: 生成的脚本无法运行

**解决方案**: 
- 确保已安装 ArcGIS Pro 2.5 或更高版本
- 使用 ArcGIS Pro 自带的 Python 解释器运行脚本
- 检查是否需要相应的 ArcGIS Pro 扩展模块

### 问题 3: 脚本工具参数配置错误

**解决方案**: 
- 确保参数配置与脚本中的 `arcpy.GetParameterAsText()` 索引一致
- 检查参数的数据类型和方向设置

## 📚 相关资源

- **ArcGIS Pro 官方文档**: https://pro.arcgis.com/zh-cn/pro-app/latest/help/analysis/
- **arcpy 参考文档**: https://pro.arcgis.com/zh-cn/pro-app/latest/arcpy/main/
- **Python 脚本工具**: https://pro.arcgis.com/zh-cn/pro-app/latest/help/analysis/geoprocessing/basics/the-script-tool-dialog-box.htm

## 🎓 学习建议

1. **从小任务开始**: 先尝试简单的功能需求，熟悉 skill 的输出格式
2. **学习 arcpy 基础**: 了解常用的 arcpy 函数和空间分析方法
3. **调试技巧**: 学会使用 `arcpy.AddMessage()` 输出调试信息
4. **参数配置**: 熟悉脚本工具参数的配置方法

## 📝 版本信息

- **Skill 版本**: 1.0
- **配置日期**: 2026-03-12
- **最后更新**: 2026-03-12
- **维护者**: WorkBuddy

---

**注意**: 此 skill 已成功配置并可以使用。你可以随时开始使用它来生成 ArcGIS Pro 插件！
