---
name: arcpy-analysis-toolbox-dev
description: >
  三阶段 ArcPy 综合分析工具箱全链路开发技能。从微信公众号/网络推文教程出发，
  经「教程网页化→综合工具箱开发→实验套件生成」三阶段，
  产出完整的 ArcGIS Pro 脚本工具箱 + 学生实验教程套件。
  This skill should be used when the user provides GIS tutorial articles (WeChat, web) and wants to:
  (1) create a structured HTML tutorial page from them,
  (2) build a comprehensive arcpy toolbox (.pyt),
  (3) generate individual experiment tutorial packages for teaching.
  Trigger phrases include: "从推文制作工具箱", "arcpy工具箱开发", "制作实验教程",
  "GIS教程转脚本工具", "全链路工具箱开发", "批量生成实验教程".
agent_created: true
---

# ArcPy 综合分析工具箱全链路开发技能

## 技能目的

将 GIS 教程推文批量转化为三件套交付物：
1. **教程网页** — 数据对象→业务逻辑的结构化 HTML 页面
2. **综合工具箱** — 可直接加载的 ArcGIS Pro `.pyt` 脚本工具箱
3. **实验教程** — 每个环节独立的 5 文件学生实验包

## 适用场景

- 用户提供一系列微信公众号/网络教程 URL
- 用户要求"从推文制作 arcpy 工具箱"
- 用户要求"将操作教程做成脚本工具实验课"
- 用户指定教程主题（如"用地适宜性评价""水文分析"等）并要求全链路输出

## 工作流程

### 第一步：解析需求，确定范围

从用户输入中提取：
- 推文 URL 列表
- 期望的输出目录（默认为 `脚本工具开发/<主题>工具箱/`）
- 目标平台（默认 ArcGIS Pro 3.x）
- 是否需要一键评价/主工具

### 第二步：Phase 1 — 教程网页化

**加载 `tutorial-to-logic` 技能**，按以下流程执行：

1. 并行 Fetch 所有推文 URL，提取完整教程内容
2. 识别核心数据对象（Feature Class、Raster、Geodatabase 等）
3. 分析对象关系 → 生成 Mermaid 类图（`classDiagram`）和数据流图（`graph TD/LR`）
4. 推导业务逻辑 → 四大阶段（准备→数据组织→视图呈现→输出）
5. 生成完整 Mermaid 操作流程图
6. 为每个环节创建操作对象对照表（操作了什么→用了什么工具→产出了什么→对象状态如何变化）
7. 输出单一 HTML 文件到 `outputs/` 目录

**注意事项**：
- Mermaid 图使用 `graph TD/LR` 而非 `erDiagram`（中文兼容性更好）
- HTML 页面结构：原理（对象+类图）→ 逻辑（业务本质+流程图）→ 过程（步骤对照+源链接）
- 页首嵌入所有教程链接索引
- 在"关键认知"板块列出常见陷阱（如评价方向不一致、处理范围统一等）

### 第三步：Phase 2 — 综合 ArcPy 工具箱开发

**直接开发**（此阶段不加载其他技能），按以下流程执行：

1. 设计工具箱架构：
   - 工具数量：覆盖教程所有独立环节 + 初始化工具 + 聚合工具 + 一键工具
   - 工具粒度：每个独立环节一个工具类
   - 代码组织：`.pyt` 主文件 + `config.py` 全局配置 + `modules/` 子模块

2. 创建目录结构和文件：
   ```
   项目文件夹/
   ├── ToolboxName.pyt
   ├── config.py
   ├── modules/
   │   ├── __init__.py
   │   ├── environment.py
   │   ├── factor_utils.py
   │   ├── aggregation.py
   │   ├── classification.py
   │   └── ahp_weights.py
   ├── tests/
   │   └── test_pipeline.py
   └── docs/
       └── 工具箱使用说明.md
   ```

3. 编写核心模块：
   - `config.py`：将教程中的默认参数（距离/权重/分级标准）固化为字典
   - `environment.py`：`setup_workspace()` 函数创建 .gdb、设置 arcpy.env
   - `factor_utils.py`：公共流水线函数（多环缓冲→联合→字段评分→面转栅格）
   - 专项模块：各因子的处理逻辑（可直接用 factor_utils 组合实现）

4. 编写 `.pyt` 工具箱：
   - `class Toolbox` 定义工具列表和分类
   - 每个工具类包含 `getParameterInfo()` + `execute()`
   - 参数标注使用中文教程术语，参数名称使用英文
   - 默认值直接使用教程原文数据
   - 每个工具包含 `keep_intermediate` 布尔参数

5. 关键适配（从 ArcMap 教程到 ArcGIS Pro）：
   - .mdb → .gdb（`CreateFileGDB`）
   - VB Script → PYTHON3 表达式
   - 手动环境设置 → `arcpy.env.extent` / `arcpy.env.cellSize`
   - 老式 arcpy 调用 → 现代路径式：`arcpy.analysis.Buffer`

6. 创建集成测试（纯 Python 逻辑验证，跳过需要 arcpy 的模块）

### 第四步：Phase 3 — 实验教程套件生成

**加载 `arcpy-arcgis-pro-plugin-generator` 技能**，按以下流程执行：

1. 创建顶层目录结构：
   ```
   实验教程套件/
   ├── 实验总览.md
   └── 共享资源/
       └── 实验环境配置指南.md
   ```

2. 为 **每个** Phase 2 的独立工具生成一个实验文件夹，每个包含 5 个文件：

   | 文件 | 内容要点 |
   |------|---------|
   | 需求分析说明.md | 功能概述、参数表（标注/名称/数据类型/类型/默认值）、数据要求 |
   | 业务逻辑分析.md | 步骤流程、arcpy 函数映射表、Mermaid 流程图 |
   | 功能脚本.py | 独立可运行的 .py，含 `GetParameterAsText(i)`、`AddMessage`、try/except |
   | 运行环境说明.md | 引用共享指南、参数配置表（截图式描述）、调试方法、常见错误 |
   | 完整教程.md | 实验目标、知识点表、操作步骤+代码、3道思考题、完成标准 |

3. 如果工具数量 ≥ 6，使用并行 Agent 加速生成：
   - Agent A：生成前一半实验包
   - Agent B：生成后一半实验包
   - 每个 Agent 的 prompt 中必须包含：完整的参数表、教程内容摘要、评分规则

4. 检查所有实验的 5 文件完整性

### 第五步：交付与验证

1. 确认三阶段产出物完整：
   - [ ] Phase 1 HTML 教程页面可正常渲染
   - [ ] Phase 2 .pyt 文件可在 ArcGIS Pro 中加载
   - [ ] Phase 3 每个实验 5 文件齐全

2. 交付核心文件给用户，附产出物清单

## 完整参考示例

参考工作：`F:\网易龙虾\脚本工具开发\用地适宜性评价工具箱\` 目录下的完整产出。

该示例基于学研录公众号 9 篇"城市用地适宜性评价"系列教程，产出：
- `outputs/城市用地适宜性评价_原理逻辑过程.html`（Phase 1）
- `UrbanSuitability.pyt` + 6 个模块文件（Phase 2）
- `实验教程套件/` 9 个实验 × 5 文件 + 2 共享文档（Phase 3）

## 参考资源

- 详细阶段规范和模板见 `references/pipeline-standards.md`
- 依赖技能（按需加载）：`tutorial-to-logic`、`arcpy-arcgis-pro-plugin-generator`
