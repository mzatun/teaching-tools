#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
网页内容抓取脚本
功能：抓取网页内容并提取正文，转换为 Markdown 格式
"""

import argparse
import sys


def fetch_webpage(url):
    """抓取网页内容并提取正文"""
    try:
        import requests
        from bs4 import BeautifulSoup
    except ImportError as e:
        missing_pkg = str(e).split("'")[1]
        raise ImportError(f"{missing_pkg} 未安装，请运行: pip install {missing_pkg}")
    
    # 设置请求头，模拟浏览器访问
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
    }
    
    try:
        # 获取网页内容
        response = requests.get(url, headers=headers, timeout=30)
        response.raise_for_status()
        response.encoding = response.apparent_encoding
        
        # 解析 HTML
        soup = BeautifulSoup(response.text, 'html.parser')
        
        # 移除不需要的标签
        for tag in soup(['script', 'style', 'nav', 'footer', 'header', 'aside', 'iframe', 'noscript']):
            tag.decompose()
        
        # 提取正文（常见的内容标签）
        content_tags = soup.find_all(['article', 'main', 'div'], class_=lambda x: x and any(
            keyword in str(x).lower() for keyword in ['content', 'post', 'article', 'text', 'body']
        ))
        
        if content_tags:
            # 使用找到的内容标签
            main_content = content_tags[0]
        else:
            # 如果没有找到特定标签，使用整个 body
            main_content = soup.find('body')
            if not main_content:
                main_content = soup
        
        # 转换为 Markdown 格式
        markdown_content = []
        
        for element in main_content.find_all(['h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'p', 'ul', 'ol', 'li', 'blockquote', 'code', 'pre']):
            tag_name = element.name
            text = element.get_text(strip=True)
            
            if not text:
                continue
            
            if tag_name == 'h1':
                markdown_content.append(f"\n# {text}\n")
            elif tag_name == 'h2':
                markdown_content.append(f"\n## {text}\n")
            elif tag_name == 'h3':
                markdown_content.append(f"\n### {text}\n")
            elif tag_name == 'h4':
                markdown_content.append(f"\n#### {text}\n")
            elif tag_name == 'h5':
                markdown_content.append(f"\n##### {text}\n")
            elif tag_name == 'h6':
                markdown_content.append(f"\n###### {text}\n")
            elif tag_name == 'blockquote':
                markdown_content.append(f"\n> {text}\n")
            elif tag_name == 'code':
                markdown_content.append(f"`{text}`")
            elif tag_name == 'pre':
                markdown_content.append(f"\n```\n{text}\n```\n")
            elif tag_name in ['ul', 'ol']:
                markdown_content.append("")
                for li in element.find_all('li', recursive=False):
                    li_text = li.get_text(strip=True)
                    if li_text:
                        prefix = '-' if tag_name == 'ul' else '1.'
                        markdown_content.append(f"{prefix} {li_text}")
                markdown_content.append("")
            elif tag_name == 'p':
                markdown_content.append(f"\n{text}\n")
        
        return "\n".join(markdown_content)
        
    except requests.exceptions.RequestException as e:
        raise Exception(f"网络请求失败: {str(e)}")
    except Exception as e:
        raise Exception(f"解析网页失败: {str(e)}")


def main():
    parser = argparse.ArgumentParser(description='抓取网页内容并转换为 Markdown 格式')
    parser.add_argument('--url', required=True, help='网页 URL')
    
    args = parser.parse_args()
    
    try:
        content = fetch_webpage(args.url)
        print(content)
    except Exception as e:
        print(f"错误：{str(e)}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
