#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
文档解析脚本
功能：解析 PDF 和 Word 文档，提取文本内容并转换为 Markdown 格式
"""

import argparse
import sys
import os


def parse_pdf(file_path):
    """解析 PDF 文档"""
    try:
        import PyPDF2
    except ImportError:
        raise ImportError("PyPDF2 未安装，请运行: pip install PyPDF2")

    text_content = []
    
    with open(file_path, 'rb') as file:
        pdf_reader = PyPDF2.PdfReader(file)
        
        for page_num, page in enumerate(pdf_reader.pages, 1):
            page_text = page.extract_text()
            if page_text.strip():
                text_content.append(f"\n## 第 {page_num} 页\n\n{page_text}\n")
    
    return "\n".join(text_content)


def parse_word(file_path):
    """解析 Word 文档"""
    try:
        from docx import Document
    except ImportError:
        raise ImportError("python-docx 未安装，请运行: pip install python-docx")

    doc = Document(file_path)
    text_content = []
    
    for para in doc.paragraphs:
        text = para.text.strip()
        if text:
            # 根据段落样式转换为 Markdown 标题
            style_name = para.style.name
            if 'Heading 1' in style_name:
                text_content.append(f"\n# {text}\n")
            elif 'Heading 2' in style_name:
                text_content.append(f"\n## {text}\n")
            elif 'Heading 3' in style_name:
                text_content.append(f"\n### {text}\n")
            else:
                text_content.append(f"{text}\n")
    
    return "\n".join(text_content)


def parse_markdown(file_path):
    """解析 Markdown 文档（直接读取）"""
    with open(file_path, 'r', encoding='utf-8') as file:
        return file.read()


def main():
    parser = argparse.ArgumentParser(description='解析 PDF、Word 或 Markdown 文档')
    parser.add_argument('--file_path', required=True, help='文档文件路径（支持 .pdf, .docx, .md）')
    
    args = parser.parse_args()
    
    # 检查文件是否存在
    if not os.path.exists(args.file_path):
        print(f"错误：文件不存在 - {args.file_path}", file=sys.stderr)
        sys.exit(1)
    
    # 根据文件扩展名选择解析方法
    file_ext = os.path.splitext(args.file_path)[1].lower()
    
    try:
        if file_ext == '.pdf':
            content = parse_pdf(args.file_path)
        elif file_ext in ['.docx', '.doc']:
            content = parse_word(args.file_path)
        elif file_ext == '.md':
            content = parse_markdown(args.file_path)
        else:
            print(f"错误：不支持的文件格式 - {file_ext}", file=sys.stderr)
            print("支持的格式：.pdf, .docx, .md", file=sys.stderr)
            sys.exit(1)
        
        # 输出解析结果
        print(content)
        
    except Exception as e:
        print(f"错误：解析文档失败 - {str(e)}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
