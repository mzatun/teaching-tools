// 用 jsdom 加载生成的升级版 HTML，真实执行内联 d3 + 应用脚本，
// 渲染四个视图并断言 4 个 Bug 的修复点。并对学习路线做“注入重复节点”的压力测试。
const fs = require('fs');
const { JSDOM } = require('jsdom');

const HTML = process.argv[2];
const html = fs.readFileSync(HTML, 'utf-8');
const errors = [];
const dom = new JSDOM(html, {
  runScripts: 'dangerously',
  pretendToBeVisual: true,
  beforeParse(window) {
    Object.defineProperty(window.HTMLElement.prototype, 'clientWidth', { get() { return 1200; }, configurable: true });
    Object.defineProperty(window.HTMLElement.prototype, 'clientHeight', { get() { return 800; }, configurable: true });
    window.addEventListener('error', e => errors.push('window.error: ' + (e.error ? e.error.stack : e.message)));
  }
});
const { window } = dom;

function run() {
  const doc = window.document;
  let failed = false;
  const assert = (name, cond, extra='') => {
    console.log((cond ? 'PASS ' : 'FAIL ') + name + (extra ? '  ['+extra+']' : ''));
    if (!cond) failed = true;
  };

  // Bug1: 知识体系树
  const tree = doc.getElementById('kb-tree');
  const treeLis = tree ? tree.querySelectorAll('li').length : 0;
  assert('Bug1 知识体系树已渲染(li>0)', treeLis > 0, 'li=' + treeLis);
  assert('Bug1 树含可折叠 toggle', !!tree.querySelector('.toggle'));

  // UI3: 侧栏 chips + 旧 category-list 已废弃
  const chips = doc.querySelectorAll('#cat-chips .cat-chip');
  assert('UI3 知识体系 chips 渲染', chips.length >= 2, 'chips=' + chips.length);
  assert('UI3 chips 默认激活"全部"', doc.querySelector('#cat-chips .cat-chip.active')?.dataset.cat === 'all');
  assert('UI3 已废弃 #category-list', !doc.getElementById('category-list'));
  // UI3: 节点等级紧凑横排 4 项
  const levelItems = doc.querySelectorAll('.level-compact .level-item');
  assert('UI3 节点等级紧凑(4项)', levelItems.length === 4, 'count=' + levelItems.length);

  // UI3: navbar 副标题静态化、长描述进 tooltip
  const subById = doc.getElementById('kb-subtitle');
  const titleEl = doc.getElementById('kb-title');
  assert('UI3 navbar 副标题不再有 id#kb-subtitle', !subById);
  assert('UI3 领域描述进 navbar-title tooltip', !!(titleEl && titleEl.getAttribute('title') && titleEl.getAttribute('title').length > 5),
         titleEl ? 'title="'+titleEl.getAttribute('title').slice(0,16)+'…"' : '');

  // 图谱
  try { window.eval('switchView("graph")'); } catch(e){ errors.push('graph: '+e.message); }
  const gNodes = doc.querySelectorAll('#graph-svg .node').length;
  assert('图谱视图渲染节点(>0)', gNodes > 0, 'nodes=' + gNodes);
  const firstLabel = doc.querySelector('#graph-svg .node text.node-label');
  const fsz = firstLabel ? firstLabel.getAttribute('font-size') : null;
  assert('Bug2 节点标签已设置 font-size', !!fsz && parseFloat(fsz) > 0, 'font-size=' + fsz);

  // 矩阵
  try { window.eval('switchView("matrix")'); } catch(e){ errors.push('matrix: '+e.message); }
  const cap = doc.querySelector('#matrix-wrap .matrix-caption');
  assert('Bug3 矩阵释义 caption 存在', !!cap, cap ? cap.textContent.slice(0,18)+'…' : '');
  assert('Bug3 矩阵表格存在', !!doc.querySelector('#matrix-wrap table.matrix'));
  assert('UI3 矩阵有图例 .matrix-legend', !!doc.querySelector('#matrix-wrap .matrix-legend'));

  // 路线：逐路线校验“唯一节点数 == 去重后唯一 KP 数”
  const routeSel = doc.getElementById('path-sel');
  const nScenarios = window.eval('KB.scenarios.length');
  for (let si = 0; si < nScenarios; si++) {
    const sc = window.eval('KB.scenarios[' + si + ']');
    try { routeSel.value = String(si); window.eval('renderRoute()'); } catch(e){ errors.push('route'+si+': '+e.message); }
    const allKP = []; sc.phases.forEach(p => (p.knowledgePoints||[]).forEach(k => allKP.push(k)));
    const uniqueKP = new Set(allKP).size;
    const realCircles = doc.querySelectorAll('#path-svg .node circle').length;
    assert(`Bug4 路线${si} 去重正确(唯一节点=${uniqueKP} == 圆=${realCircles})`, realCircles === uniqueKP, `unique=${uniqueKP} circles=${realCircles}`);
  }

  // 压力测试：向路线0注入跨阶段重复节点，验证占位 chip 出现且仍只画一次真实节点
  window.eval('(function(){ var sc=KB.scenarios[0]; var dup=sc.phases[0].knowledgePoints[0]; sc.phases[1].knowledgePoints.push(dup); window.__dupNode=dup; })()');
  const uniqueKP2 = window.eval('(function(){ var s=KB.scenarios[0]; var a=[]; s.phases.forEach(p=>(p.knowledgePoints||[]).forEach(k=>a.push(k))); return new Set(a).size; })()');
  try { routeSel.value = '0'; window.eval('renderRoute()'); } catch(e){ errors.push('route0-dup: '+e.message); }
  const realCircles2 = doc.querySelectorAll('#path-svg .node circle').length;
  assert('Bug4[压力] 注入重复后仍只画唯一节点', realCircles2 === uniqueKP2, `unique=${uniqueKP2} circles=${realCircles2}`);
  const chip = Array.from(doc.querySelectorAll('#path-svg text')).map(t=>t.textContent).find(t=>t.includes('已在阶段'));
  assert('Bug4[压力] 跨阶段复用占位提示出现', !!chip, chip || 'no chip');
  // 还原
  window.eval('KB.scenarios[0].phases[1].knowledgePoints.pop()');

  console.log('\n--- 运行时错误（jsdom 环境，SVG transform 相关可在真浏览器忽略）---');
  if (errors.length === 0) console.log('NONE');
  else errors.forEach(e => console.log(e));
  if (failed) process.exitCode = 1;
}

if (window.document.readyState === 'complete') run();
else window.addEventListener('load', () => setTimeout(run, 300));
