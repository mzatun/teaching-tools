#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
kb-html-builder · 注入脚本
============================
将 kb-source-organizer 产出的 Consolidated JSON 注入 HTML 模板（references/kb-template.html）
的 `__KB_DATA__` 占位符，生成**自包含单文件 HTML**（D3 已内联，零 CDN，双击即开）。

用法：
    python build_html.py <input.json> <output.html> [--template <tpl.html>]

参数：
    input.json     Consolidated JSON（含 title/nodes/links/categories，可选 dimensions/scenarios）
    output.html    生成的单文件 HTML 路径（建议用"专题名-知识体系.html"命名）
    --template     可选，自定义模板；默认按脚本位置定位到 references/kb-template.html

设计约束（与 kb-source-organizer 输出契约一致）：
    - nodes[].level  (1-4)        → 节点大小+字号
    - nodes[].importance (0.5-1)  → 字号微调
    - nodes[].category            → 配色分类
    - nodes[].parent/children     → 左侧知识体系树
    - dimensions[].purpose        → 矩阵 caption 行/列释义
    - scenarios[].phases[].knowledgePoints → 路线（去重+跨阶段复用占位）
"""
import json
import os
import argparse

HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT_TPL = os.path.join(os.path.dirname(HERE), "references", "kb-template.html")


def main():
    ap = argparse.ArgumentParser(description="Consolidated JSON → 自包含知识体系 HTML")
    ap.add_argument("input", help="Consolidated JSON 路径")
    ap.add_argument("output", help="输出 HTML 路径")
    ap.add_argument("--template", default=DEFAULT_TPL, help="HTML 模板路径（默认 references/kb-template.html）")
    args = ap.parse_args()

    # 1. 读取模板
    with open(args.template, "r", encoding="utf-8") as f:
        tpl = f.read()
    assert "__KB_DATA__" in tpl, f"模板中未找到 __KB_DATA__ 占位符：{args.template}"

    # 2. 读取数据并校验关键字段
    with open(args.input, "r", encoding="utf-8") as f:
        kb = json.load(f)
    assert isinstance(kb.get("nodes"), list) and len(kb["nodes"]) > 0, "nodes 缺失或为空"
    assert "links" in kb, "links 缺失"

    # 3. 注入
    payload = json.dumps(kb, ensure_ascii=False)
    out = tpl.replace("const KB = __KB_DATA__;", "const KB = " + payload + ";", 1)
    assert out != tpl, "占位符替换未发生"

    # 4. 写出
    out_dir = os.path.dirname(os.path.abspath(args.output))
    os.makedirs(out_dir, exist_ok=True)
    with open(args.output, "w", encoding="utf-8") as f:
        f.write(out)

    # 5. 报告
    print("OK 生成:", args.output)
    print("  节点:", len(kb.get("nodes", [])),
          "| 关系:", len(kb.get("links", [])),
          "| 路线:", len(kb.get("scenarios", [])),
          "| 维度:", len(kb.get("dimensions", [])))
    print("  有children字段节点:", sum(1 for n in kb["nodes"] if n.get("children")),
          "| 有importance节点:", sum(1 for n in kb["nodes"] if "importance" in n))


if __name__ == "__main__":
    main()
