# kb-html-builder · 知识体系 HTML 应用构建器

把 **kb-source-organizer** 产出的 Consolidated JSON 一键转成**自包含单文件 HTML** 知识体系可视化应用（D3 已内联、零 CDN、双击即开）。

## 上下游
```
主题 → kb-source-organizer → kb-consolidated.json → [本技能] → 专题名-知识体系.html
```

## 目录结构
```
kb-html-builder/
├── SKILL.md                 # 技能说明 / 触发词 / 工作流
├── README.md                # 本文件
├── references/
│   ├── kb-template.html     # HTML 模板（内联 D3 v7，含 __KB_DATA__ 占位符）
│   └── design-spec.md       # 设计方法说明书（四视图/侧栏/矩阵/路线/避坑）
├── scripts/
│   ├── build_html.py        # JSON → HTML 注入
│   └── verify_html.js       # jsdom 四视图+4Bug 验证
└── examples/
    └── remote-sensing/      # 开箱即跑示例（kb-consolidated.json）
```

## 依赖
- **生成（必需）**：Python 3（仅文本注入，无第三方依赖）。
- **验证（可选）**：Node.js + `jsdom@24`（`npm install jsdom@24`，设 `NODE_PATH` 指向 node_modules）。浏览器直开无需。

## 使用流程
1. 准备 Consolidated JSON（先用 kb-source-organizer 生成，或自带符合契约的 JSON）。
2. 生成网页：
   ```bash
   python scripts/build_html.py examples/remote-sensing/kb-consolidated.json 输出.html
   ```
3. （可选）无头验证：
   ```bash
   NODE_PATH=<node_modules> node scripts/verify_html.js 输出.html
   ```
4. 双击 `输出.html` 即可交互；离线可用。

## 自带示例
```bash
python scripts/build_html.py examples/remote-sensing/kb-consolidated.json examples/remote-sensing/遥感智能计算-知识体系.html
```

## 设计要点（详见 design-spec.md）
- 单文件自包含，D3 内联，零 CDN。
- 四视图：知识图谱 / 知识导图 / 矩阵 / 学习路线。
- 侧栏三段：知识体系(chips+树) / 节点等级(紧凑) / 关系类型。
- 矩阵 caption 三段式（行/列/色各一行 + 强色标），杜绝行/列语义混淆。
- 路线去重 + 跨阶段复用占位「↺ 已在阶段N学」。

## 与 kb-source-organizer 的字段契约
模板消费 `nodes[].level/importance/category/parent/children`、`dimensions[].purpose`、`scenarios[].phases[].knowledgePoints` 与 `sharedNodeIds`。详见 design-spec.md §2 数据契约。
