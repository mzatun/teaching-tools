# kb-html-builder · 设计方法说明书

本文件沉淀「遥感智能计算-升级版.html」的完整设计方法与决策，供后续专题复用与模板升级时遵循。
模板载体：`references/kb-template.html`（内联 D3 v7，含 `const KB = __KB_DATA__;` 占位符）。

---

## 1. 产品定位

| 维度 | 要求 |
|------|------|
| 形态 | **单文件 HTML**，D3 已内联，零 CDN 引用 |
| 运行 | 双击即开 / 任意静态服务器可部署，无需联网 |
| 交互 | 四视图切换 + 侧栏筛选 + 详情面板 + 缩放平移 |
| 数据 | 运行时由 `KB` 全局对象提供（来自 Consolidated JSON） |

> 反例：引外部 CDN 的 D3 → 离线打不开、分享时需收件方联网。一律内联。

---

## 2. 数据契约（Consolidated JSON）

与上游 `kb-source-organizer` 输出一致。最小可用字段：

```jsonc
{
  "title": "专题名",
  "subtitle": "长描述（进 navbar tooltip，不占菜单位置）",
  "nodes": [
    {
      "id": "rs_ndvi",
      "label": "NDVI",
      "category": "cat_remote_sensing",   // 对应 categories[].id
      "level": 2,                          // 1-4：核心/重要/一般/扩展
      "importance": 0.85,                  // 0.5-1.0，分化明显
      "parent": "rs_index",                // 树父节点 id；根节点 null
      "children": ["rs_ndvi_trend"],        // 子节点 id 列表（由 validate_kb 生成）
      "tags": { "phase": "p_apply", "ability": "a_code" },  // 维度取值，用于矩阵
      "difficulty": "medium"               // 入门/中等/较难/前沿 → 矩阵色块
    }
  ],
  "links": [ { "source": "a", "target": "b", "type": "depends", "weight": 0.8 } ],
  "categories": [ { "id": "cat_remote_sensing", "name": "遥感原理", "color": "#3b82f6" } ],
  "dimensions": [                          // 至少 2 个才能画矩阵
    { "id": "phase", "name": "学习阶段", "purpose": "按认知深度划分…回答需要学到什么程度" },
    { "id": "ability", "name": "能力类型", "purpose": "按能力性质划分…回答学到什么能力" }
  ],
  "scenarios": [
    {
      "name": "入门路线", "role": "寒窗砥本科生", "totalTime": 600,
      "phases": [ { "name": "阶段1·基础", "knowledgePoints": ["id1","id2"] } ],
      "sharedNodeIds": ["id_x"]            // 跨阶段复用节点（validate_kb 自动算）
    }
  ]
}
```

**7 类关系**（links[].type）：`depends / constrains / contains / extends / evolved / analogy / contrast`。

---

## 3. 四视图设计原则

### 3.1 知识图谱（force-directed）
- 力导布局：charge -400 + forceX/Y(中心).strength(0.05) + forceCenter + forceCollide + link.distance 90+(1-weight)*60。
- 节点圆大小 = `config.nodeSizes[level]`；字号 = `base(level) + (importance-0.5)*3`（L1≈16.5 / L4≈9.5）。
- 点击节点 → 高亮邻居 + 右侧详情面板（tags / 度量 / 关联）。
- 关系类型用颜色或线型区分；侧栏关系筛选可隐藏某类边。

### 3.2 知识导图（mindmap）
- 从根节点按 `parent/children` 递归展开的层级树，可折叠。
- 与侧栏「知识体系树」同源，保证两处一致。

### 3.3 矩阵（matrix）⚠️ 易踩坑
- 选两个 `dimensions` 作行/列；单元格列出同时满足两维取值的节点。
- **caption 必须三段式**（本版核心修复）：
  - 🔵 行 = `<维度名>`：`<purpose>`
  - 🟢 列 = `<维度名>`：`<purpose>`
  - 🟠 色 = 单元格色块：按 `difficulty` 着色，点击看详情
  - 行/列/色各占一行 + 强色标 + 虚线分隔 → 杜绝"行/列语义搅成一坨"。
- 难度配色：入门 #3b82f6 / 中等 #22c55e / 较难 #f59e0b / 前沿 #ef4444。
- **反例**：单行 inline 拼接 purpose，purpose 内引号会切碎句尾，读者分不清行/列。

### 3.4 学习路线（learning route）
- 每阶段一行，节点按阶段内顺序横排。
- **去重规则**：节点仅在「首次出现阶段」画真实圆；后续阶段若复用 → 画「↺ 节点名（已在阶段N学）」占位（来自 `scenarios[].sharedNodeIds`）。
- 阶段间依赖箭头用虚线 + marker。
- 信息栏措辞：「面向 X · 总学时 Y 分钟 · 共 Z 个阶段 · 跨阶段复用 N 个节点」（避免"角色：X 总学时：Y 分"式堆砌）。

---

## 4. 侧栏三段式（关键布局决策）

| 段 | 内容 | 说明 |
|----|------|------|
| 知识体系 | category chips（全部+各版块带计数，点击=图谱过滤）+ 下方层级树 | 原"知识版块"+"知识体系树"两合并，消除重复 |
| 节点等级 | 4 列紧凑横排（核心/重要/一般/扩展） | 原竖排被挤出屏 → 改横排 |
| 关系类型 | 关系筛选 | 保留 |

- **已删除**："操作提示"段（噪音，详情/hover 已够用）。
- **navbar 副标题**：固定"升级版"静态；长描述进 `kb-title` 原生 `title` tooltip，不挤菜单。

---

## 5. 视觉规范

- 字体：系统无衬线；正文 12-13px，标题 14-16px。
- 配色：版块渐变（category.color）；难度四色（上）；关系七色。
- 间距：sidebar 各段 padding 16-20px；视图区内边距 16px。
- 圆角：卡片 8px；tag 4px。

---

## 6. 验证契约（verify_html.js）

用 jsdom 加载整页并真实执行四视图，断言：
1. 知识体系树 li > 0 且含 `.toggle` 折叠；
2. category chips 渲染且默认激活"全部"；旧 `#category-list` 已废弃；
3. 节点等级紧凑 4 项；
4. navbar 无 `id=kb-subtitle`、长描述进 `kb-title.title`；
5. 图谱节点 > 0 且标签有 font-size；
6. 矩阵 caption 存在（`mc-row/mc-tag/mc-axis` 结构）+ 表格 + 图例 `.matrix-legend`；
7. 每条路线 `真实圆数 == 去重后唯一 KP 数`（防重复项回归）；
8. 压力测试：注入跨阶段重复节点 → 仍只画唯一节点 + 出现「↺ 已在阶段N学」占位。

> jsdom 不支持 SVG `transform.baseVal`，真实浏览器无此问题；脚本对缩放复位加 try/catch 兜底。
> 运行时错误（除 jsdom SVG 限制外）应为 NONE。

---

## 7. 已知坑（避坑清单）

1. **矩阵 caption 切忌单行拼接** purpose（见 3.3）。
2. **路线重复项**：渲染时直接 `ph.knowledgePoints` 定位会每个出现都画圆 → 必须按首现阶段去重。
3. **节点等级竖排被挤出屏** → 改紧凑横排。
4. **侧栏"知识版块"与"知识体系树"重复** → 合并为一段（chips+树）。
5. **navbar 副标题挤菜单** → 静态化 + 长描述进 tooltip。
6. **D3 必须内联**，不可 CDN。
7. **占位符替换**用 `tpl.replace("const KB = __KB_DATA__;", "const KB = "+payload+";", 1)`，一次替换防误伤。
