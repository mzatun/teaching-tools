---
name: kb-html-builder
description: >-
  将「知识图谱数据源」技能 kb-source-organizer 产出的 Consolidated JSON 注入内联 D3 的 HTML
  模板，生成**自包含单文件知识体系可视化应用**（零 CDN、双击即开）。当用户说"把
  kb-consolidated.json 转成 HTML 知识体系应用""生成可视化知识体系网页""用 JSON 出
  单文件知识图谱""复用 kb-pro 模板做网页""把这份数据做成可交互的知识图谱/矩阵/学习路线页"时触发。
  上下游：上游 kb-source-organizer（5 份 YAML → Consolidated JSON）；本技能（JSON → HTML）。
agent_created: true
version: "1.0"
---

# kb-html-builder · 知识体系 HTML 应用构建器

把结构化知识数据（Consolidated JSON）渲染成一个**自包含、零依赖、双击即开**的交互式网页，
内置四种视图：**知识图谱 / 知识导图 / 矩阵 / 学习路线**。

## 何时用
- 已有 kb-source-organizer 产出的 `kb-consolidated.json`，想转成可交付网页。
- 收到任意符合 Consolidated JSON 契约的 JSON，想快速出可视化。
- 需要复刻"人月聊IT"式「任意领域可视化知识体系」网页。

## 上下游衔接
```
主题 → kb-source-organizer → kb-consolidated.json → [本技能] → 单文件 HTML
        (5 YAML → 校验 → JSON)            (JSON → 注入模板 → 验证)
```
- 若还没有 JSON：先调用 `kb-source-organizer` 生成。
- 若已有 JSON：直接进本技能的 Step 1。

## 工作流

### Step 1 · 确认输入
- 输入 = Consolidated JSON（路径或粘贴内容）。
- 校验最小契约：`nodes`(非空数组) + `links`。可选 `categories / dimensions / scenarios`。
- 字段细节见 `references/design-spec.md` 的「数据契约」段。

### Step 2 · 注入生成
```bash
python <skill>/scripts/build_html.py <input.json> <output.html> [--template <tpl.html>]
```
- 模板默认 = `<skill>/references/kb-template.html`（已内联 D3 v7，含 `__KB_DATA__` 占位符）。
- 输出建议命名为 `专题名-知识体系.html`，放到用户工作区。
- 脚本会打印节点/关系/路线/维度统计，并自检占位符替换成功。

### Step 3 · 无头验证（推荐，防回归）
```bash
# 需要 jsdom：npm install jsdom@24 后设 NODE_PATH 指向 node_modules
NODE_PATH=<node_modules> node <skill>/scripts/verify_html.js <output.html>
```
- 断言四视图均渲染、侧栏三段、矩阵三段式 caption、路线去重正确，无运行时错误。
- 详见 `references/design-spec.md`「验证契约」。

### Step 4 · 交付
- 把 `<output.html>` 交给用户（自包含，可直接双击或部署到任意静态服务器）。
- 提示：D3 已内联，无需联网；如需改配色/文案，改模板或数据后重跑 Step 2。

## 依赖
- Python 3（仅做文本注入，无第三方依赖；托管/系统 Python 均可）。
- Node.js + `jsdom@24`（仅 Step 3 验证用，可选；浏览器直开无需）。

## 设计原则（摘要，全文见 references/design-spec.md）
- **单文件自包含**：D3 内联，零 CDN，双击即开。
- **四视图**：图谱(力导)/导图(层级树)/矩阵(二维度交叉)/路线(阶段化学习路径)。
- **侧栏三段**：知识体系(chips+树) / 节点等级(紧凑) / 关系类型。
- **节点视觉编码**：level→圆大小+字号；importance→字号微调；category→配色。
- **矩阵三段式 caption**：行/列/色 各一行，强语义色标，避免行/列语义搅在一起。
- **路线去重**：节点仅在首现阶段画真实圆，跨阶段复用画「↺ 已在阶段N学」占位。

## Notes
- 模板即产品：改 `references/kb-template.html` 等于升级所有未来产出；改动后跑 Step 3 验证。
- Consolidated JSON 字段若与 `kb-source-organizer` 输出不一致，按 `design-spec.md` 契约对齐。
