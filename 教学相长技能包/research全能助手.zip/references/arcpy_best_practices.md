# ArcPy最佳实践指南

本文档总结了ArcPy编程中的最佳实践，帮助用户编写高效、可靠的GIS脚本。

---

## 1. 环境配置

### 1.1 工作空间设置

```python
import arcpy
import os

# 设置工作空间（推荐使用raw字符串避免转义问题）
arcpy.env.workspace = r"C:\GIS_Data\Project"

# 覆盖输出（允许覆盖已存在的文件）
arcpy.env.overwriteOutput = True

# 设置输出坐标系
arcpy.env.outputCoordinateSystem = arcpy.SpatialReference("WGS 1984")

# 设置并行处理因子（利用多核CPU）
arcpy.env.parallelProcessingFactor = "75%"
```

### 1.2 许可管理

```python
import arcpy

# 检查并检出扩展模块许可
def checkout_extensions():
    """检出必要的扩展模块许可"""
    try:
        # 检查基础许可
        if arcpy.CheckExtension("Spatial") == "Available":
            arcpy.CheckOutExtension("Spatial")
        else:
            raise RuntimeError("Spatial许可不可用")

        # 检查3D Analyst（如果需要TIN/ Terrain处理）
        if arcpy.CheckExtension("3D") == "Available":
            arcpy.CheckOutExtension("3D")

        print("所有许可检出成功")
        return True
    except Exception as e:
        print(f"许可检出失败: {e}")
        return False

def return_extensions():
    """归还扩展模块许可"""
    try:
        arcpy.CheckInExtension("Spatial")
        arcpy.CheckInExtension("3D")
        print("许可已归还")
    except Exception as e:
        print(f"许可归还失败: {e}")
```

---

## 2. 数据访问

### 2.1 da游标使用（推荐）

```python
import arcpy

# 使用da游标进行高效读写
def update_field_with_da():
    """使用da游标更新字段"""
    fc = r"C:\GIS\Data\Cities.shp"

    # 使用with语句确保资源释放
    with arcpy.da.UpdateCursor(fc, ["POPULATION", "DENSITY", "AREA"]) as cursor:
        for row in cursor:
            # 计算人口密度（避免除零）
            if row[2] > 0:  # area > 0
                row[1] = row[0] / row[2]  # population / area
            else:
                row[1] = 0
            cursor.updateRow(row)

    print("字段更新完成")

# 使用SearchCursor读取数据
def read_features():
    """使用da SearchCursor读取要素"""
    fc = r"C:\GIS\Data\Cities.shp"

    # 使用列表推导式高效读取
    features = [
        (row[0], row[1], row[2])
        for row in arcpy.da.SearchCursor(fc, ["NAME", "POPULATION", "SHAPE@AREA"])
    ]

    return features

# 使用InsertCursor插入数据
def insert_features():
    """使用da InsertCursor插入新要素"""
    fc = r"C:\GIS\Data\Cities.shp"
    sr = arcpy.Describe(fc).spatialReference  # 获取空间参考

    with arcpy.da.InsertCursor(fc, ["SHAPE@", "NAME", "POPULATION"]) as cursor:
        # 创建点几何
        point = arcpy.Point(116.4, 24.3)  # 梅州
        geometry = arcpy.PointGeometry(point, sr)

        # 插入新记录
        cursor.insertRow([geometry, "New City", 100000])

    print("新记录插入完成")
```

### 2.2 in_memory工作空间

```python
import arcpy

# 使用in_memory提高中间数据处理速度
def process_in_memory():
    """使用in_memory工作空间进行高效处理"""

    # 在内存中创建临时缓冲区
    buffer_output = "in_memory/buffer_result"
    arcpy.Buffer_analysis(
        "Roads.shp",
        buffer_output,
        "100 Meters"
    )

    # 在内存中进行叠加分析
    intersect_output = "in_memory/intersect_result"
    arcpy.Intersect_analysis(
        [buffer_output, "Parks.shp"],
        intersect_output
    )

    # 将结果复制到磁盘（仅最终结果）
    arcpy.CopyFeatures_management(intersect_output, "Final_Result.shp")

    # 清理内存
    arcpy.Delete_management("in_memory")

    print("in_memory处理完成")
```

---

## 3. 错误处理

### 3.1 异常处理模板

```python
import arcpy
import sys

def safe_geoprocessing():
    """安全的地理处理函数"""
    try:
        # 设置环境
        arcpy.env.workspace = r"C:\GIS\Project"
        arcpy.env.overwriteOutput = True

        # 执行地理处理
        arcpy.Buffer_analysis("Roads.shp", "Buffer.shp", "100 Meters")

        # 检查输出是否生成
        if arcpy.Exists("Buffer.shp"):
            result = arcpy.GetCount_management("Buffer.shp")
            count = int(result.getOutput(0))
            print(f"缓冲区包含 {count} 个要素")
        else:
            raise RuntimeError("缓冲分析未生成输出文件")

    except arcpy.ExecuteError:
        # 地理处理执行错误
        messages = arcpy.GetMessages()
        print(f"地理处理错误:\n{messages}")
        # 获取更详细的错误信息
        for msg in range(0, arcpy.GetMessageCount()):
            print(f"消息 {msg}: {arcpy.GetMessage(msg)}")

    except Exception as e:
        # 一般异常处理
        print(f"程序执行错误: {str(e)}")
        import traceback
        traceback.print_exc()

    finally:
        # 清理资源
        print("执行完成")
```

### 3.2 验证数据集存在

```python
def validate_inputs(input_fc, input_field):
    """验证输入数据有效性"""

    # 检查要素类是否存在
    if not arcpy.Exists(input_fc):
        raise ValueError(f"输入数据集不存在: {input_fc}")

    # 检查要素类是否有要素
    count_result = arcpy.GetCount_management(input_fc)
    count = int(count_result.getOutput(0))
    if count == 0:
        raise ValueError(f"输入数据集为空: {input_fc}")

    # 检查字段是否存在
    fields = [f.name for f in arcpy.ListFields(input_fc)]
    if input_field not in fields:
        raise ValueError(f"字段不存在: {input_field}")

    # 检查几何类型
    desc = arcpy.Describe(input_fc)
    if desc.shapeType != "Polygon":
        raise ValueError(f"输入数据应为面要素，当前类型: {desc.shapeType}")

    print("输入数据验证通过")
    return True
```

---

## 4. 性能优化

### 4.1 批量处理优化

```python
import arcpy
from concurrent.futures import ThreadPoolExecutor

def batch_process_feature_classes():
    """批量处理多个要素类"""
    arcpy.env.workspace = r"C:\GIS\Data"

    # 获取所有要素类
    fc_list = arcpy.ListFeatureClasses()

    # 准备处理参数
    processing_params = [(fc, "100 Meters") for fc in fc_list]

    # 使用多线程并行处理
    with ThreadPoolExecutor(max_workers=4) as executor:
        futures = [
            executor.submit(process_single_fc, fc, distance)
            for fc, distance in processing_params
        ]

        # 收集结果
        results = [f.result() for f in futures]

    return results

def process_single_fc(fc, distance):
    """处理单个要素类"""
    try:
        output = fc.replace(".shp", "_buffer.shp")
        arcpy.Buffer_analysis(fc, output, distance)
        return {"status": "success", "output": output}
    except Exception as e:
        return {"status": "error", "fc": fc, "error": str(e)}
```

### 4.2 空间索引优化

```python
def optimize_spatial_index(fc):
    """优化要素类的空间索引"""

    desc = arcpy.Describe(fc)

    # 检查是否需要重建索引
    if desc.hasSpatialIndex:
        print(f"要素类已有空间索引: {fc}")
        return

    # 重建空间索引
    arcpy.AddSpatialIndex_management(
        fc,
        spatial_grid_index1="0",
        spatial_grid_index2="0",
        spatial_grid_index3="0"
    )

    print(f"空间索引已重建: {fc}")
```

---

## 5. 常用工具函数

### 5.1 创建要素类

```python
def create_point_fc(output_path, spatial_reference="WGS 1984"):
    """创建点要素类"""
    arcpy.CreateFeatureclass_management(
        out_path=os.path.dirname(output_path),
        out_name=os.path.basename(output_path),
        geometry_type="POINT",
        spatial_reference=spatial_reference
    )

    # 添加字段
    arcpy.AddField_management(output_path, "NAME", "TEXT", field_length=100)
    arcpy.AddField_management(output_path, "VALUE", "DOUBLE")

    return output_path
```

### 5.2 批量投影转换

```python
def batch_project(fc_list, output_dir, target_sr):
    """批量投影转换"""
    for fc in fc_list:
        try:
            output = os.path.join(output_dir, os.path.basename(fc))
            arcpy.Project_management(
                fc,
                output,
                target_sr
            )
            print(f"投影完成: {fc} -> {output}")
        except Exception as e:
            print(f"投影失败: {fc}, 错误: {e}")
```

### 5.3 要素类统计信息

```python
def get_fc_statistics(fc):
    """获取要素类统计信息"""
    desc = arcpy.Describe(fc)

    stats = {
        "name": desc.name,
        "type": desc.datasetType,
        "shapeType": desc.shapeType,
        "extent": desc.extent,
        "spatialReference": desc.spatialReference.name,
        "featureCount": int(arcpy.GetCount_management(fc)[0])
    }

    return stats
```

---

## 6. 日志记录

### 6.1 地理处理日志

```python
import logging
import datetime

def setup_logging(log_file="geoprocessing.log"):
    """配置日志记录"""
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(levelname)s - %(message)s",
        handlers=[
            logging.FileHandler(log_file, encoding='utf-8'),
            logging.StreamHandler()
        ]
    )
    return logging.getLogger(__name__)

logger = setup_logging()

def logged_geoprocessing(func):
    """地理处理日志装饰器"""
    def wrapper(*args, **kwargs):
        start_time = datetime.datetime.now()
        logger.info(f"开始执行: {func.__name__}")

        try:
            result = func(*args, **kwargs)
            elapsed = datetime.datetime.now() - start_time
            logger.info(f"执行成功: {func.__name__}, 耗时: {elapsed}")
            return result
        except Exception as e:
            elapsed = datetime.datetime.now() - start_time
            logger.error(f"执行失败: {func.__name__}, 耗时: {elapsed}, 错误: {e}")
            raise

    return wrapper
```

---

## 7. 常见问题解决

### 问题1：路径包含中文字符

```python
import arcpy
import os

# 解决方案1：使用raw字符串
path = r"D:\数据\地理信息\测试数据.shp"

# 解决方案2：使用os.path处理
path = os.path.join("D:", "数据", "地理信息", "测试数据.shp")

# 解决方案3：使用正斜杠（ArcGIS支持）
path = "D:/数据/地理信息/测试数据.shp"
```

### 问题2：字段名称包含特殊字符

```python
# ArcGIS字段名称限制：
# - 英文、数字、下划线
# - 不能以数字开头
# - 最多10个字符（Shapefile）

# 解决方案：重命名字段
def sanitize_field_name(name):
    """清理字段名称"""
    import re
    # 替换特殊字符为下划线
    name = re.sub(r'[^a-zA-Z0-9_]', '_', name)
    # 确保不以数字开头
    if name[0].isdigit():
        name = '_' + name
    # 截断到10个字符（Shapefile）
    return name[:10]
```

### 问题3：处理大文件内存不足

```python
def process_large_fc_chunked(fc, chunk_size=10000):
    """分块处理大型要素类"""

    count_result = arcpy.GetCount_management(fc)
    total_count = int(count_result[0])

    offset = 0
    while offset < total_count:
        # 使用SQL子句分块读取
        where_clause = f"OBJECTID > {offset} AND OBJECTID <= {offset + chunk_size}"

        with arcpy.da.SearchCursor(fc, ["SHAPE@"], where_clause=where_clause) as cursor:
            for row in cursor:
                # 处理每个要素
                process_feature(row[0])

        offset += chunk_size
        print(f"已处理 {min(offset, total_count)}/{total_count}")
```
