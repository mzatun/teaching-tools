# GIS研究方法指南

本文档为GIS和遥感研究提供系统性的研究方法指导。

---

## 1. 研究问题定义

### 1.1 问题类型

| 类型 | 描述 | 示例 |
|------|------|------|
| 描述性 | 回答"是什么" | 土地利用现状分析 |
| 解释性 | 回答"为什么" | 城市扩张驱动力分析 |
| 预测性 | 回答"会怎样" | 未来土地利用变化预测 |
| 规范性 | 回答"应该怎样" | 最佳选址规划 |

### 1.2 研究问题特征

好的研究问题应具备：
- **明确性**：问题表述清晰，无歧义
- **可研究性**：有可行的数据和方法支撑
- **重要性**：对学科或实践有意义
- **创新性**：不重复已有研究
- **可验证性**：可以通过实验或数据分析验证

---

## 2. 文献综述方法

### 2.1 文献检索策略

```python
# 文献检索关键词示例
keywords = {
    "主题词": ["remote sensing", "image fusion", "deep learning"],
    "同义词": ["multi-scale", "pansharpening", "sharpening"],
    "相关词": ["convolutional neural network", "CNN", "neural network"],
    "限定词": ["urban", "high resolution", "VHR"]
}

# 布尔逻辑组合
search_query = """
("remote sensing" OR "earth observation")
AND ("image fusion" OR "pansharpening")
AND ("deep learning" OR "CNN" OR "convolutional neural network")
NOT "medical"
"""
```

### 2.2 主要数据库

| 数据库 | 类型 | 适用领域 |
|--------|------|----------|
| Web of Science | 综合引文 | 高影响力期刊 |
| Scopus | 综合引文 | 工程、计算机 |
| IEEE Xplore | 会议/期刊 | 电子电气 |
| arXiv | 预印本 | 最新研究 |
| CNKI | 中文期刊 | 中国研究 |
| Geo数据库 | 地球科学 | 地学相关 |

---

## 3. 数据收集与管理

### 3.1 遥感数据源

```python
# 常用遥感数据源
data_sources = {
    "免费光学卫星": [
        "Landsat (USGS EarthExplorer)",
        "Sentinel-2 (ESA Copernicus Open Access Hub)",
        "MODIS (NASA LP DAAC)"
    ],
    "免费雷达卫星": [
        "Sentinel-1 (ESA)",
        "ALOS PALSAR (Japan Space Systems)"
    ],
    "商业高分辨率": [
        "WorldView (Maxar)",
        "GeoEye (Maxar)",
        "PlanetScope (Planet Labs)"
    ],
    "国产卫星": [
        "高分系列 (资源卫星中心)",
        "资源三号 (自然资源卫星云平台)",
        "环境卫星"
    ]
}

# 数据下载脚本示例
def download_sentinel2(product_id, output_dir):
    """下载Sentinel-2数据"""
    # 使用sentine2downloader库
    from sentinelsat import SentinelAPI

    api = SentinelAPI('username', 'password', 'https://apihub.copernicus.eu/apihub')

    # 查询产品
    products = api.query_by_id(product_id)

    # 下载
    api.download_all(products, directory_path=output_dir)
```

### 3.2 矢量数据源

```python
# 常用矢量数据
vector_sources = {
    "行政区划": [
        "全国地理信息资源目录服务系统",
        "民政部行政区划数据",
        "高德/百度行政区划API"
    ],
    "道路网络": [
        "OpenStreetMap",
        "全国交通数据中心",
        "导航电子地图"
    ],
    "土地利用": [
        " GlobeLand30 (30m全球地表覆盖)",
        "FROM-GLC (30m全球地表覆盖)",
        "ESA CCI Land Cover (300m)"
    ]
}
```

---

## 4. 实验设计

### 4.1 对照实验设计

```python
# 实验设计模板
experiment_design = {
    "实验目的": "验证提出方法的有效性",
    "实验对象": {
        "实验组": "提出的方法",
        "对照组": [
            "传统方法1",
            "传统方法2",
            "最新方法1",
            "最新方法2"
        ]
    },
    "控制变量": [
        "数据集",
        "图像分辨率",
        "参数设置",
        "评估指标"
    ],
    "实验变量": "融合方法",
    "因变量": "融合质量评估指标"
}
```

### 4.2 数据集划分

```python
from sklearn.model_selection import train_test_split

def split_dataset(data, train_ratio=0.7, val_ratio=0.15, test_ratio=0.15):
    """划分训练集、验证集、测试集"""

    # 确保比例之和为1
    assert train_ratio + val_ratio + test_ratio == 1.0

    # 划分训练集和剩余集
    train_data, remaining = train_test_split(
        data,
        train_size=train_ratio,
        random_state=42
    )

    # 划分验证集和测试集
    val_size = val_ratio / (val_ratio + test_ratio)
    val_data, test_data = train_test_split(
        remaining,
        train_size=val_size,
        random_state=42
    )

    return train_data, val_data, test_data
```

---

## 5. 评估指标

### 5.1 图像融合质量评估

```python
import numpy as np
from skimage.metrics import peak_signal_noise_ratio, structural_similarity

def evaluate_fusion(pan_image, fused_image, ms_image=None):
    """评估融合图像质量"""

    results = {}

    # 1. 峰值信噪比 (PSNR)
    results['PSNR'] = peak_signal_noise_ratio(
        pan_image,
        fused_image,
        data_range=pan_image.max() - pan_image.min()
    )

    # 2. 结构相似性 (SSIM)
    results['SSIM'] = structural_similarity(
        pan_image,
        fused_image,
        data_range=pan_image.max() - pan_image.min()
    )

    # 3. 光谱角映射 (SAM) - 需要多光谱图像
    if ms_image is not None:
        def spectral_angle(img1, img2):
            """计算光谱角"""
            # 展平为向量
            vec1 = img1.flatten()
            vec2 = img2.flatten()
            # 计算SAM
            cos_angle = np.dot(vec1, vec2) / (np.linalg.norm(vec1) * np.linalg.norm(vec2))
            return np.arccos(np.clip(cos_angle, -1, 1)) * 180 / np.pi

        results['SAM'] = spectral_angle(ms_image, fused_image)

    # 4. 相对通用光谱质量 (ERGAS)
    # 需要多波段数据

    return results
```

### 5.2 空间精度评估

```python
from scipy.spatial.distance import directed_hausdorff

def evaluate_spatial_accuracy(result_shp, reference_shp):
    """评估空间精度"""

    # 1. Hausdorff距离
    def hausdorff_distance(shp1, shp2):
        """计算Hausdorff距离"""
        points1 = extract_boundary_points(shp1)
        points2 = extract_boundary_points(shp2)

        d1 = directed_hausdorff(points1, points2)[0]
        d2 = directed_hausdorff(points2, points1)[0]

        return max(d1, d2)

    # 2. 面积重叠度 (IoU)
    def intersection_over_union(shp1, shp2):
        """计算交并比"""
        intersection = shp1.intersection(shp2).area
        union = shp1.union(shp2).area
        return intersection / union if union > 0 else 0

    return {
        'hausdorff_distance': hausdorff_distance(result_shp, reference_shp),
        'iou': intersection_over_union(result_shp, reference_shp)
    }
```

---

## 6. 方法对比分析

### 6.1 统计显著性检验

```python
from scipy import stats

def compare_methods(results_dict):
    """
    比较不同方法的性能差异是否具有统计显著性

    results_dict: {方法名: [结果列表]}
    """

    methods = list(results_dict.keys())
    comparisons = []

    # 配对t检验（适用于同一数据集上的比较）
    for i in range(len(methods)):
        for j in range(i+1, len(methods)):
            method1, method2 = methods[i], methods[j]
            results1 = results_dict[method1]
            results2 = results_dict[method2]

            # 配对t检验
            t_stat, p_value = stats.ttest_rel(results1, results2)

            comparisons.append({
                'method1': method1,
                'method2': method2,
                't_statistic': t_stat,
                'p_value': p_value,
                'significant': p_value < 0.05
            })

    return comparisons
```

### 6.2 Friedman检验（非参数）

```python
def friedman_test(all_results):
    """
    使用Friedman检验比较多个方法

    all_results: {方法名: [结果列表]}，假设每个方法在相同数据集上测试
    """

    methods = list(all_results.keys())
    k = len(methods)  # 方法数
    n = len(all_results[methods[0]])  # 数据集数

    # 构建排名矩阵
    rankings = []
    for dataset_idx in range(n):
        dataset_results = [(methods[i], all_results[methods[i]][dataset_idx])
                         for i in range(k)]
        # 按性能降序排名（越高越好）
        sorted_results = sorted(dataset_results, key=lambda x: x[1], reverse=True)
        ranks = {m: r+1 for r, (m, _) in enumerate(sorted_results)}
        rankings.append([ranks[m] for m in methods])

    # 计算平均排名
    avg_ranks = np.mean(rankings, axis=0)

    # Friedman统计量
    chi2_stat = 12 * n / (k * (k + 1)) * np.sum((avg_ranks - (k + 1) / 2) ** 2)

    return {
        'avg_ranks': dict(zip(methods, avg_ranks)),
        'chi2_statistic': chi2_stat,
        'best_method': methods[np.argmin(avg_ranks)]
    }
```

---

## 7. 结果可视化

### 7.1 地图可视化

```python
import plotly.express as px
import plotly.graph_objects as go

def create_map_visualization(gdf, column, title):
    """创建交互式地图"""

    fig = px.choropleth_mapbox(
        gdf,
        geojson=gdf.geometry.__geo_interface__,
        locations=gdf.index,
        color=column,
        mapbox_style="carto-positron",
        zoom=5,
        center={"lat": 24.5, "lon": 116.0},
        title=title
    )

    fig.update_layout(
        margin={"r": 0, "t": 30, "l": 0, "b": 0},
        height=600
    )

    return fig
```

### 7.2 多图对比

```python
def create_comparison_figure(images, titles, methods):
    """创建方法对比图"""

    from plotly.subplots import make_subplots

    n = len(images)
    fig = make_subplots(
        rows=1, cols=n,
        subplot_titles=titles,
        horizontal_spacing=0.05
    )

    for i, (img, method) in enumerate(zip(images, methods), 1):
        fig.add_trace(
            go.Heatmap(z=img, colorscale='gray', showscale=(i == n)),
            row=1, col=i
        )

    fig.update_layout(
        title_text="不同方法的融合效果对比",
        height=400
    )

    return fig
```

---

## 8. 研究报告撰写

### 8.1 研究报告结构

```markdown
# 研究报告结构

## 1. 引言
### 1.1 研究背景
### 1.2 研究意义
### 1.3 主要贡献

## 2. 相关工作与理论基础
### 2.1 理论基础
### 2.2 国内外研究现状
### 2.3 现有方法的局限性

## 3. 研究方法
### 3.1 总体框架
### 3.2 数据来源与预处理
### 3.3 技术方案
### 3.4 实验设计

## 4. 实验结果与分析
### 4.1 实验环境
### 4.2 主观评价
### 4.3 客观评价
### 4.4 对比分析
### 4.5 消融实验

## 5. 讨论
### 5.1 方法优势
### 5.2 局限性
### 5.3 适用范围

## 6. 结论与展望
### 6.1 主要结论
### 6.2 未来工作

## 参考文献
```

### 8.2 方法论检查清单

```markdown
## 方法论检查清单

### 数据层面
- [ ] 数据来源明确
- [ ] 数据质量已验证
- [ ] 预处理步骤已记录
- [ ] 数据划分合理

### 方法层面
- [ ] 方法原理清晰
- [ ] 参数设置合理
- [ ] 对比基线适当
- [ ] 实验设置可重复

### 评估层面
- [ ] 评估指标选择合理
- [ ] 统计检验完备
- [ ] 结果可重复验证

### 报告层面
- [ ] 论文结构完整
- [ ] 图表清晰规范
- [ ] 引用准确完整
- [ ] 语言表达准确
```
