# 科研全能助手技能包 (Research Master Assistant)

**版本**: v1.0 龙虾定制版  
**基于**: DeepScientist V1.5  
**创建日期**: 2026-04-04  
**适用场景**: GIS科研、遥感研究、地理信息科学、ArcPy开发

---

## 技能概述

本技能包基于西湖大学张岳实验室开源的DeepScientist项目，针对**嘉应学院GIS/测绘教学科研场景**进行了深度龙虾化改造。

### 核心四大功能

1. **复现与假设生成** - 论文复现、文献调研、Idea生成
2. **智能代码调试** - ArcPy脚本调试、自动化实验、迭代优化
3. **实验数据分析** - 数据处理、可视化(Plotly)、洞察挖掘
4. **论文自动撰写** - LaTeX论文生成、格式规范、图表制作

---

## 技能激活

**触发关键词**: `科研全能`, `research`, `论文复现`, `代码调试`, `实验分析`, `论文撰写`

**触发条件**: 当用户涉及以下场景时自动激活：
- 需要复现某篇论文的实验
- 遇到ArcPy/Python代码bug需要调试
- 需要分析实验数据并生成可视化
- 需要撰写或润色学术论文
- 需要生成论文Idea或研究方向

---

## 目录结构

```
research全能助手/
├── SKILL.md                    # 本文件 - 技能配置
├── README.md                   # 详细使用说明
├── log/                        # 科研日志目录
│   ├── YYYY-MM-DD.md           # 每日科研日志
│   └── memory/                 # 长期记忆存储
├── modules/                    # 功能模块
│   ├── 01_paper_reproduction.md    # 论文复现模块
│   ├── 02_code_debugging.md        # 代码调试模块
│   ├── 03_data_analysis.md         # 数据分析模块
│   └── 04_paper_writing.md        # 论文撰写模块
├── prompts/                   # 提示词模板
│   ├── research_start.md           # 研究启动提示词
│   ├── code_debug.md               # 代码调试提示词
│   ├── data_analysis.md            # 数据分析提示词
│   └── paper_writing.md            # 论文撰写提示词
├── templates/                 # 论文模板
│   ├── latex_template.tex          # LaTeX论文模板
│   ├── 中文期刊模板.tex             # 中文期刊模板
│   └── cover_letter.md             # 投稿信模板
└── references/               # 参考资料
    ├── arcpy_best_practices.md     # ArcPy最佳实践
    ├── gis_research_methods.md     # GIS研究方法
    └── academic_writing.md         # 学术写作规范
```

---

## 核心工作流程

### 1. 研究启动流程

```
用户输入研究目标
    ↓
解析研究类型（论文复现/代码调试/数据分析/论文撰写）
    ↓
创建研究项目目录（工作区/research_projects/项目名）
    ↓
初始化Git仓库并记录日志
    ↓
执行对应功能模块
    ↓
记录科研日志到 log/YYYY-MM-DD.md
    ↓
生成研究报告/代码/数据/论文
```

### 2. 四大核心功能

#### 功能一：复现与假设生成
- 根据arXiv/GitHub链接自动复现论文
- 调研相关文献，生成新颖研究Idea
- 支持中英文论文分析
- 特别优化：GIS/遥感领域论文复现

#### 功能二：智能代码调试与优化
- 支持ArcPy、Python、JavaScript代码调试
- 自动化运行实验、错误分析
- 从错误中迭代优化
- 特别优化：ArcGIS Pro环境兼容

#### 功能三：实验数据自动化分析
- 支持CSV、Excel、Shapefile数据处理
- Plotly交互式可视化
- 自动生成分析报告和优化建议
- 特别优化：空间数据分析

#### 功能四：论文自动撰写
- LaTeX论文自动生成
- 支持中文期刊格式（遥感学报、测绘学报等）
- 自动图表生成和代码开源
- 特别优化：GIS/测绘领域术语

---

## GitHub集成配置

如需使用GitHub功能，请配置以下凭证：

```yaml
github:
  username: mzatun
  # 密码请在首次使用时提供，或设置环境变量 GITHUB_TOKEN
  # export GITHUB_TOKEN="your_personal_access_token"
```

**建议**：使用Personal Access Token替代密码：
1. GitHub Settings → Developer settings → Personal access tokens
2. Generate new token (classic)
3. 勾选 repo, workflow 权限
4. 使用token替代密码进行git操作

---

## 科研日志规范

所有科研活动自动记录到 `log/YYYY-MM-DD.md`：

```markdown
# 科研日志 YYYY-MM-DD

## 今日研究项目
- 项目名称：[项目名]
- 项目路径：research_projects/xxx

## 完成的工作
1. [具体工作内容]
2. ...

## 发现与洞察
- [重要发现]
- [优化建议]

## 下一步计划
- [ ] 任务1
- [ ] 任务2

## 遇到的问题
- 问题描述及解决方案

## 代码片段记录
```python
# 关键代码片段
```
```

---

## 龙虾化特色

1. **GIS/遥感专项优化**
   - ArcPy环境自动检测和配置
   - Shapefile/GeoJSON/GeoPackage格式支持
   - GIS领域专业术语库

2. **Plotly可视化优先**
   - 交互式图表生成
   - 地图可视化支持
   - 科研图表模板

3. **教学科研双场景**
   - 支持课程作业辅助
   - 支持科研项目开展
   - 支持论文发表

4. **本地优先安全**
   - 所有数据本地存储
   - Git版本控制
   - 可随时接管

---

## 使用示例

### 示例1：论文复现
```
用户：帮我复现这篇论文的实验：https://arxiv.org/abs/xxxxx
助手：[激活论文复现模块，自动克隆代码、处理依赖、运行实验]
```

### 示例2：代码调试
```
用户：我的ArcPy脚本报错了，无法批量处理shp文件
助手：[激活代码调试模块，分析错误原因，给出修复方案]
```

### 示例3：数据分析
```
用户：分析这个CSV文件，生成可视化报告
助手：[激活数据分析模块，读取数据、生成Plotly图表、输出分析报告]
```

### 示例4：论文撰写
```
用户：帮我写一篇关于"基于深度学习的遥感影像分类"的论文
助手：[激活论文撰写模块，根据用户提供的信息生成完整论文草稿]
```

---

## 接口说明

### 外部接口

1. **GitHub API** (可选)
   - 端点：api.github.com
   - 认证：Bearer Token
   - 用途：代码仓库管理

2. **arXiv API** (可选)
   - 端点：export.arxiv.org/api/query
   - 用途：论文元数据获取

3. **Plotly Chart Studio** (可选)
   - 端点：api.plotly.com
   - 用途：云端图表托管

### 环境变量

```bash
# GitHub认证
export GITHUB_TOKEN="ghp_xxxxx"

# OpenAI API (如使用)
export OPENAI_API_KEY="sk-xxxxx"

# 工作区路径
export RESEARCH_WORKSPACE="f:/网易龙虾/research_projects"

# 日志目录
export RESEARCH_LOG_DIR="f:/网易龙虾/.workbuddy/skills/research全能助手/log"
```

---

## 版本历史

| 版本 | 日期 | 更新内容 |
|------|------|----------|
| v1.0 | 2026-04-04 | 初始版本，基于DeepScientist龙虾化定制 |

---

## 参考资源

- DeepScientist原版: https://github.com/ResearAI/DeepScientist
- DeepScientist论文: https://openreview.net/pdf?id=cZFgsLq8Gs
- ICLR 2026

---

*本技能包由WorkBuddy科研助手团队维护*
