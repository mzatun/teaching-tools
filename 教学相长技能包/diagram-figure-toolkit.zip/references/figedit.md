# FigEdit 详细指令

从光栅图片生成可编辑矢量图形包。输出 `editable.svg` + `editable.pptx`。

## 决策门（必须按序执行）

### 1. 结构门
面板、卡片、框架、分隔线、网格 → 重绘为 SVG 形状

### 2. 文字门
标签、标题、图注、图例 → 重打为可编辑文本（OCR 仅作参考，需核对原图）

### 3. 公式门
公式、行内数学符号 → `math` 元素 + 归一化 LaTeX，**绝不作为 `type: "text"` 处理**

### 4. 栅格资产门
图标、Logo、截图、地图、图表主体、照片 → 从原图裁切保留，**不替换为通用 SVG**

## 工作流程

### Step 1：测量（准备证据）
```bash
python scripts/prepare_measurements.py <输入图片> --out <工作目录>/work
```
输出：`ocr_results.json` / `detected_primitives.json` / `style_tokens.json` / `measurement_report.md` + 诊断叠加图

**只作证据，不直接转为最终 SVG 元素。**

### Step 2：图片路由分类
根据图片类型加载对应 references：
| 图片类型 | 加载参考 |
|---------|---------|
| 简单文字/形状图 | manifest_spec.md / svg_authoring.md / quality_checklist.md |
| 混合面板（工作流/架构/方法）| + taxonomy.md / workflow.md |
| 含公式 | + formula-reconstruction.md |
| 含图标/截图/Logo/地图 | + element_decision_matrix.md / asset_preservation_policy.md / asset_extraction.md |

### Step 3：编写 manifest.json
逐元素决策，填写 `decision_reason`。关键字段：
- `type`: `"panel"` / `"text"` / `"math"` / `"image"` / `"arrow"`
- `source_region`: 裁切区域（栅格资产）
- `text_policy`: `"extract-editable"` / `"preserve-raster"` / `"allow-embedded-text"`

### Step 4：组装输出包
```bash
python scripts/compose_svg_package.py manifest.json --out <输出目录>
```
输出：`editable.svg` / `editable_embedded.svg` / `editable.pptx` / `preview.png` / `quality_report.md` / `editability_report.md`

### Step 5：验证与修复
检查 `preview.png` + `quality_report.md`，出现以下情况需修复：
- 主要面板/流向缺失
- 裁切资产被裁剪
- OCR 文字错误但标记为确定
- 公式残留在 `type: "text"` 中
- `editability_report.md` 显示文字提取率 < 0.45

## 图层规范
| 图层 | 内容 |
|------|------|
| `background` | 背景色、填充面板矩形 |
| `assets` | 栅格资产图片 |
| `panels` | 面板边框（`fill: none`）|
| `connectors` | 箭头/连接线 |
| `texts` | 标签和渲染后的公式 |

**禁止**：在图像资产上方绘制填充面板矩形（会遮挡资产）。

## 质量门槛
- ✅ 主要标题、关键标签可编辑
- ✅ 主要面板和分组关系正确
- ✅ 来源特有视觉资产已保留（地图/图表/截图）
- ✅ 所有公式转为可编辑 OMML（PowerPoint 中可编辑）
- ✅ SVG 无检测器噪声
- ✅ 文字提取率 ≥ 0.45（有 OCR 证据时）

## 脚本地图
| 脚本 | 用途 |
|------|------|
| `prepare_measurements.py` | OCR/CV/风格证据采集 |
| `compose_svg_package.py` | 从 manifest 组装输出包 |
| `export_pptx_from_svg.py` | SVG → 原生 PPTX |
| `audit_editability.py` | 审计文字提取率和资产风险 |
| `validate_manifest.py` | manifest 校验 |

## 依赖
```
opencv-python>=4.9
paddleocr>=3.7
paddlepaddle>=3.3
numpy>=1.24
Pillow>=10.0
scipy>=1.10
matplotlib>=3.7
latex2mathml>=3.81
lxml>=5.0
```
安装：`pip install -r requirements.txt -i https://pypi.tuna.tsinghua.edu.cn/simple`

## 技能路径
`C:\Users\admin\.workbuddy\skills\figedit\`
