# arch-diagrammer 详细指令

生成架构图/流程图，支持纯 SVG 分层图 或 Mermaid/PlantUML + Kroki 渲染。可调用 `next-ai-drawio` MCP 服务导出 .drawio 文件。

## 产出模式

### 模式一：纯 SVG 分层架构图（推荐）
直接生成纯 SVG，无需外部渲染，支持 11+ 种风格。

**风格选择**：
| 风格 | 特点 | 论文/报告适用 |
|------|------|----------------|
| `blue` | 深蓝商务渐变 | ✅ 企业正式 |
| `gray` | 简约灰阶 | ✅ 论文嵌入（打印友好）|
| `morandi` | 低饱和度复古 | ✅ 设计感报告 |
| `ocean` | 海洋蓝绿 | ✅ 清新科技 |
| `tailwind` | 多色层级区分 | 层级复杂图 |
| `cyber` | 黑底霓虹色 | 科技演示（非打印）|
| `dark` | GitHub Dark | 开发者文档 |

### 模式二：Mermaid/PlantUML/Graphviz + Kroki
用图形 DSL 描述，通过 Kroki 渲染。适用：流程图、时序图、C4 架构图。

## 工作流

### 画图前：确认 4 项
1. **产出模式**：纯 SVG vs DSL+Kroki
2. **图类型**：分层架构 / 流程图 / 时序图 / C4 / 部署图
3. **层级**：层数（常见 2-5 层）、每层模块、是否要图例
4. **风格**：从上述 11+ 种选，或默认 `blue`（论文用 `gray`）

### 纯 SVG 分层架构图步骤
1. 确定层级划分（不固定 2-5 层）
2. 选定配色风格
3. 基于模板绘制层级容器与子模块（画布高度按层数动态调整）
4. **只画必要的直接关系/关键路径**，不强行连所有区块
5. 添加箭头连线与标注（最少文字说明）
6. 添加图例
7. 对照 `references/architecture-checklist.md`（arch-diagrammer 技能内）自检
8. **版式检查**（避免重叠）：
   - 层级标题与子模块预留 8-12px
   - 子模块与层级容器底部预留 10-16px
   - 图例不要贴底，必要时增加画布高度
9. **中文编码检查**（避免乱码）：
   - 输出 `<?xml version="1.0" encoding="UTF-8"?>`
   - **推荐**：中文用 XML 数字字符引用（`&#x6743;` 等），不依赖文件编码

### Mermaid/PlantUML/Graphviz 步骤
1. 明确目标与范围
2. 选择图类型（C4/流程图/时序图/部署图）
3. 起稿与迭代（从粗到细）
4. 渲染：`scripts/render_kroki.py`
5. 质量检查

## 调用 next-ai-drawio MCP

当需要 .drawio 文件时，调用 MCP 工具：
```
start_session → create_new_diagram（完整 XML）→ export_diagram（.drawio / .svg / .png）
```

**XML 格式要点**（mxGraphModel）：
```xml
<mxGraphModel>
  <root>
    <mxCell id="0"/>
    <mxCell id="1" parent="0"/>
    <mxCell id="2" value="形状" style="rounded=1;" vertex="1" parent="1">
      <mxGeometry x="100" y="100" width="120" height="60" as="geometry"/>
    </mxCell>
  </root>
</mxGraphModel>
```
- ID 从 "2" 开始（0 和 1 保留）
- `parent="1"` 顶层形状
- 布局约束：x=0-800, y=0-600（单页视口）
- 箭头用 `exitX/exitY/entryX/entryY` 控制连接点

## 质量检查清单
- [ ] 命名清晰一致（系统/服务/模块/接口）
- [ ] 图例清晰，系统边界明确
- [ ] 分层合理，不超载信息
- [ ] 箭头方向正确，标注简洁
- [ ] 中文无乱码（用 `&#xXXXX;` 或确认 UTF-8）
- [ ] 无重叠（层级标题/子模块/图例间距足够）

## 参考文件（arch-diagrammer 技能内）
- `references/svg-layered-spec.md`：11+ 种风格规范、配色表
- `references/diagram-quickstart.md`：Mermaid/PlantUML/Graphviz 语法速查
- `references/architecture-checklist.md`：质量检查清单
- `assets/svg-templates/`：各风格 SVG 模板

## 触发条件
- 用户说"生成架构图" / "画一个系统图" / "流程图"
- 用户明确要求 .drawio 文件
- 论文/报告需要正式架构图
