# Fireworks Tech Graph 详细指令

生成生产级 SVG 技术图表，导出为 PNG。覆盖架构图、数据流图、Agent 架构图、UML 全系列、思维导图等。

## 图表类型与布局规则

| 图表类型 | 布局 | ViewBox（默认）|
|---------|------|----------------|
| 架构图 | 水平分层（Client→Gateway→Services→Data）| `0 0 960 600` |
| 数据流图 | 强调数据移动，每条箭头标注数据类型 | `0 0 960 600` |
| 流程图 |  top→bottom，菱形判断，圆角矩形过程 | 网格对齐（x:120px, y:80px）|
| Agent 架构图 | 5 层：Input→Agent Core→Memory→Tool→Output | `0 0 960 700` |
| 时序图 | 垂直线条（lifeline），消息箭头 top→bottom | 高度 = 80 + num×50 |
| 对比矩阵 | 列=系统，行=属性，交替行填充 | `0 0 960 400` |
| 思维导图 | 中心节点 cx=480,cy=280，分支 360/N 度 | `0 0 960 600` |
| 类图（UML）| 3  compartment 矩形，继承空心三角 | `0 0 960 600` |
| 用例图（UML）| 参与者左侧，用例椭圆内部，系统边界虚线框 | `0 0 960 600` |
| 状态图（UML）| 初始● 左上，最终●○ 右下，flow top→bottom | `0 0 960 600` |
| ER 图 | 实体矩形，关系菱形，基数标注 | `0 0 960 600` |

## 形状词汇（跨类型统一）

| 概念 | 形状 | 备注 |
|---------|-------|-------|
| 用户/人 | 圆形+身体路径（火柴人）| |
| LLM/模型 | 圆角矩形，渐变填充 | 强调色 |
| Agent/编排器 | 六边形或双边框圆角矩形 | "主动控制器" 信号 |
| 记忆（短期）| 圆角矩形，虚线边框 | 短暂 = 虚线 |
| 记忆（长期）| 圆柱体 | 持久 = 实心圆柱 |
| 工具/函数 | 齿轮状矩形或扳手图标 | |
| API/网关 | 六边形（单边框）| |
| 外部服务 | 矩形+云图标或虚线边框 | |
| 文件/文档 | 折角矩形 | |

## 箭头语义（必须指定含义）

| 流类型 | 颜色 | 线型 | 含义 |
|-----------|-------|---------|-------|
| 主数据流 | `#2563eb` 蓝 | 2px 实线 | 主请求/响应路径 |
| 控制/触发 | `#ea580c` 橙 | 1.5px 实线 | 一系统触发另一系统 |
| 记忆读取 | `#059669` 绿 | 1.5px 实线 | 从存储检索 |
| 记忆写入 | `#059669` 绿 | 1.5px `5,3` 虚线 | 写入/存储操作 |
| 异步/事件 | `#6b7280` 灰 | 1.5px `4,2` 虚线 | 非阻塞，事件驱动 |
| 嵌入/转换 | `#7c3aed` 紫 | 1px 实线 | 数据转换 |

**使用 2+ 箭头类型时必须添加图例。**

## 布局规则

**间距**：
- 同层节点：水平 80px，层间 120px
- 画布边距：最小 40px
- 对齐网格：8px（水平 120px 间隔，垂直 120px 间隔）

**箭头标签**（关键）：
- 默认偏移 6-8px（不覆盖箭头线）
- 水平箭头标签在上方，垂直箭头标签在左侧/右侧 8px
- ≤3 个词，多条箭头汇聚时错开 15-20px

**箭头布线**：
- 优先正交（L 形）路径，减少交叉
- 锚定在组件边缘，非几何中心
- 不可避免的交叉用跳跃弧（半径 5px）

## 风格选择（8 种）

| # | 名称 | 背景 | 推荐用途 |
|---|------|-----------|----------|
| 1 | **Flat Icon**（默认）| 白色 | 论文、报告、文档 |
| 2 | Dark Terminal | `#0f0f1a` | 开发者文档、GitHub |
| 3 | Blueprint | `#0a1628` | 架构文档 |
| 6 | Claude Official | 暖奶油 `#f8f6f3` | Anthropic 风格报告 |
| 8 | Dark Luxury | `#0a0a0a` 深黑 | 高端报告、封面图 |

**默认**：Style 1（Flat Icon）。

## SVG 技术规则

**生成方法（强制 Python 列表法）**：
```python
python3 << 'EOF'
lines = []
lines.append('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 960 600">')
lines.append('  <defs>')
# ... 每行独立
lines.append('</svg>')
with open('/path/to/output.svg', 'w') as f:
    f.write('\n'.join(lines))
print("SVG generated successfully")
EOF
```

**为什么强制**：防止字符截断、拼写错误、语法错误。

**验证（生成后必须执行）**：
```bash
python3 -c "import xml.etree.ElementTree as ET; ET.parse('file.svg')" && echo "✓ Valid XML"
```

## PNG 导出（推荐 cairosvg）

```bash
# 2x 分辨率（推荐，视网膜屏/高清文档）
python3 -c "import cairosvg; cairosvg.svg2png(url='input.svg', write_to='output.png', scale=2)"

# 批量转换
python3 -c "
import cairosvg, os, glob
d = 'output/'
for svg in sorted(glob.glob(os.path.join(d, '*.svg'))):
    png = svg.replace('.svg', '.png')
    cairosvg.svg2png(url=svg, write_to=png, scale=2)
    print(f'Done: {os.path.basename(svg)}')
"
```

**方法对比**：
| 工具 | 质量 | 说明 |
|------|------|-------|
| `cairosvg`（推荐）| ✅ 好 | CSS 支持好，pip install 一次 |
| `rsvg-convert` | ⚠️ 一般 | 可能丢失 CSS 样式和 `<foreignObject>` |
| `puppeteer` | ✅✅ 最好 | 真实浏览器引擎，100% 保真，但重（Node+Chromium）|

## 视觉自检（导出 PNG 后）

如果运行时可以读取图片，加载导出的 PNG 并检查：
- 箭头是否穿过组件内部（应绕行）
- 标签是否与箭头线重叠（应偏移 6-8px）
- 框之间是否重叠（应增加间距或画布尺寸）
- 图例是否覆盖内容（应移到空白区域）

如果看到以上任何问题，修改 SVG 并重新导出。

## 工作流程（始终按顺序）

1. **分类**图表类型
2. **提取结构** — 从用户描述识别层、节点、边、流、语义组
3. **规划布局** — 应用上述布局规则
4. **加载风格参考** — 默认加载 Style 1，或用户指定
5. **映射节点到形状** — 使用上述形状词汇
6. **检查图标需求** — 已知产品查 `references/icons.md`（fireworks 技能内）
7. **编写 SVG** — 使用 Python 列表法
8. **验证** — XML 语法检查
9. **导出 PNG** — 使用 cairosvg
10. **报告**生成文件路径

## 触发条件
- 用户说"画图" / "帮我画" / "生成图" / "做个图"
- 用户描述系统/流/架构/概念需要可视化
- 论文/报告需要技术图表
