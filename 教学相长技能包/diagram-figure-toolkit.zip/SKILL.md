---
name: diagram-figure-toolkit
description: 论文配图/报告配图/软件文档配图/使用手册配图 统一工具包。自动判断需求类型，路由到最合适的制图引擎：从零画图（arch-diagrammer / fireworks-tech-graph）或图片矢量化编辑（figedit）。触发词：画图、生成图、架构图、流程图、把这张图转成可编辑、论文配图、报告配图、软件文档配图。
version: 1.0.0
author: 钟广锐
---

# 图表配图工具包（Diagram Figure Toolkit）

统一处理四类常见配图需求：**论文配图、研究报告配图、软件文档配图、使用手册配图**。

## 决策树（第一步：判断需求类型）

```
用户需求
│
├─ 已有图片，想改成可编辑格式？
│  └─ 是 → 【路线A：FigEdit 矢量化】→ 读 references/figedit.md
│
└─ 从零开始画一张图？
   │
   ├─ 图片用途 = 使用手册 / 操作教程（截图+标注）？
   │  └─ 是 → 【路线A：FigEdit 路线】先生成/收集截图，再用 FigEdit 添加可编辑标注
   │
   ├─ 图类型 = 架构图 / 流程图 / 部署图 / 系统图？
   │  ├─ 需要导入 draw.io 编辑？→ 【路线B1：arch-diagrammer + draw.io】
   │  └─ 只要 SVG/PNG 交付？→ 【路线B2：fireworks-tech-graph 直接出图】
   │
   ├─ 图类型 = 时序图 / 类图 / UML / ER图 / 状态图？
   │  └─ 【路线B2：fireworks-tech-graph】（UML 覆盖最完整）
   │
   ├─ 图类型 = 概念图 / 思维导图 / 对比矩阵 / 时间线？
   │  └─ 【路线B2：fireworks-tech-graph】
   │
   └─ 不确定 → 向用户确认（最多问 1 个问题）：「这张图主要用于哪里？用于决定画图风格。」
```

---

## 路线A：FigEdit 图片矢量化（已有图片 → 可编辑 SVG/PPTX）

**适用场景**：
- 论文中有 AI 生成的配图，想改文字/颜色
- 截图/照片/地图需要变成可编辑矢量图
- 使用手册需要把截图改成可编辑格式

**工作流程**：
1. 读取 `references/figedit.md`（完整工作流）
2. 按照 FigEdit 技能的流程执行：测量 → 决策 → 组装 → 验证
3. 输出：`editable.svg` + `editable.pptx` + `quality_report.md`

**关键命令**：
```bash
# 测量阶段
python scripts/prepare_measurements.py <输入图片> --out <工作目录>

# 组装阶段（模型生成 manifest.json 后）
python scripts/compose_svg_package.py manifest.json --out <输出目录>
```

**技能路径**：`C:\Users\admin\.workbuddy\skills\figedit\`

---

## 路线B1：arch-diagrammer + draw.io（架构图 → .drawio 文件）

**适用场景**：
- 需要导入 draw.io 继续编辑
- 系统架构图、方案架构图
- 用户明确要求用 draw.io

**工作流程**：
1. 读取 `references/arch-diagrammer.md`
2. 选择模式：
   - **模式一**：纯 SVG 分层架构图（11+ 种风格）
   - **模式二**：Mermaid/PlantUML + Kroki 渲染
3. 调用 `next-ai-drawio` MCP 服务创建/编辑图表
4. 导出 `.drawio` 文件

**MCP 工具**：
- `mcp__next-ai-drawio__start_session`
- `mcp__next-ai-drawio__create_new_diagram`
- `mcp__next-ai-drawio__export_diagram`

**风格选择**（模式一）：
| 风格 | 适用 |
|------|------|
| blue | 企业正式文档 |
| gray | 论文嵌入（打印友好）|
| morandi | 设计感报告 |
| cyber | 科技演示 |
| tailwind | 层级复杂图 |

---

## 路线B2：fireworks-tech-graph 直接出图（技术图 → SVG/PNG）

**适用场景**：
- 论文配图（架构图、数据流图、Agent 架构图）
- 研究报告（对比矩阵、时间线、概念图）
- 软件文档（UML 类图、时序图、状态图）
- 只要 SVG/PNG，不需要导入其他工具编辑

**工作流程**：
1. 读取 `references/fireworks-tech-graph.md`
2. 分类图表类型（架构图/数据流图/流程图/Agent架构图/时序图/UML/...）
3. 选择风格（默认 Style 1: Flat Icon）
4. 生成 SVG → 导出 PNG
5. 视觉自检（箭头交叉、文字碰撞、图例覆盖）

**输出**：
- `<图表名>.svg`（主要交付物）
- `<图表名>.png`（文档嵌入用）
- `<图表名>_report.md`（可选，说明文档）

**风格选择**：
| 风格 | 适用 |
|------|------|
| 1-Flat Icon（默认）| 论文、报告、文档 |
| 2-Dark Terminal | 开发者文档、GitHub |
| 3-Blueprint | 架构文档 |
| 6-Claude Official | Anthropic 风格报告 |
| 8-Dark Luxury | 高端报告、封面图 |

---

## 快速场景映射

| 使用场景 | 推荐路线 | 输出格式 |
|---------|---------|-----------|
| 论文方法章节框架图 | B2（fireworks）| SVG + PNG |
| 论文系统架构图 | B1（arch + draw.io）或 B2 | .drawio 或 SVG |
| 研究报告流程图 | B2（fireworks）| SVG + PNG |
| 研究报告对比矩阵 | B2（fireworks）| SVG + PNG |
| 软件文档类图/时序图 | B2（fireworks）| SVG |
| 软件文档部署架构图 | B1（arch + draw.io）| .drawio |
| 使用手册截图标注 | A（FigEdit）| PPTX（可编辑）|
| AI 生成的图想改文字 | A（FigEdit）| SVG + PPTX |
| 地图/照片/图表想矢量化 | A（FigEdit）| SVG |

---

## 输出规范

### 文件命名
- 论文配图：`fig_<章节>_<简述>.svg`（例：`fig_3_method_framework.svg`）
- 报告配图：`report_<日期>_<简述>.svg`
- 软件文档：`doc_<模块>_<简述>.svg`
- 使用手册：`manual_<章节>_<简述>.pptx`

### 存放路径
- 默认：`F:\网易龙虾\教学相长\论文报告配图\`
- 可指定其他路径

### 交付检查
- [ ] SVG 在浏览器中打开正常（无乱码）
- [ ] PNG 分辨率 ≥ 2x（用于高清文档）
- [ ] 论文配图：无背景色（透明或白色），适合打印
- [ ] 报告配图：有配色方案，视觉一致
- [ ] 软件文档：UML 符号规范
- [ ] 使用手册：PPTX 中文字可编辑

---

## 参考资料

- FigEdit 完整工作流 → `references/figedit.md`
- arch-diagrammer 详细指令 → `references/arch-diagrammer.md`
- fireworks-tech-graph 详细指令 → `references/fireworks-tech-graph.md`
- 图表类型与风格推荐 → `references/style-guide.md`（可选）

---

*初次使用某路线时，读取对应 references 文件获取详细指令。后续相同路线可凭记忆执行，无需重复读取。*
